<?php include 'inventory.php' ?>



<main>
    <section class="add-category-section">
        <form action="function.php" method="POST">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" onclick="location.href='categories.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="" class="form-label">Categoray Name</label>
                        <input type="text" name="category_name" class="form-control" 
                        placeholder="ex:TV,Refrigirator" required 
                        oninput="this.value = this.value.toUpperCase()">
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="save_categories" class="btn btn-primary">Save</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
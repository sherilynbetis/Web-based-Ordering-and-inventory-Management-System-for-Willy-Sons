<?php include 'inventory.php' ?>



<main>
    <section class="add-product-section">
        <form action="function.php" method="POST" enctype="multipart/form-data">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <p class="fw-bold">ADD PRODUCTS</p>
                    <button type="button" onclick="location.href='inventory.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="">Brand Name</label>
                        <input type="text" name="brand_name" class="form-control" value="<?php echo $_SESSION['brand_name'] ?? '';  ?>" placeholder="Enter Brand" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Product Name</label>
                        <input type="text" name="product_name" class="form-control" value="<?php echo $_SESSION['product_name'] ?? '';  ?>" placeholder="Enter Product" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Category</label>
                        <select name="category" id="" class="form-control" required>
                            <option value="<?php echo $_SESSION['category'] ?? 'Select' ?>"><?php echo $_SESSIO_SESSIONn['category'] ?? 'Select' ?></option>
                            <?php
                            $get_cat = $conn->prepare("SELECT * FROM `categories`");
                            $get_cat->execute();
                            $result_cat = $get_cat->get_result();
                            if($result_cat->num_rows>0){
                                while($row_cat = mysqli_fetch_assoc($result_cat)){
                                    $category_name = htmlspecialchars($row_cat['category_name']);
                                    $category_id  = htmlspecialchars($row_cat['category_id']);
                                    ?>
                                    <option value="<?php echo $category_id; ?>"><?php echo $category_name; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="">Status</label>
                        <select name="status" id="" class="form-control">
                            <option value="<?php echo $_SESSION['status'] ?? 'Select'; ?>"><?php echo $_SESSION['status'] ?? 'Select'; ?></option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="">Price</label>
                        <input type="number" name="price" class="form-control" value="<?php echo $_SESSION['price'] ?? '';  ?>" placeholder="Enter Price" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control p-2" id=""><?php echo  $_SESSION['description'] ?? '';  ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="">Images</label>
                        <input type="file" name="images[]" class="form-control" accept=".jpg,jpeg,.png" multiple required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="save_product" class="btn btn-primary">Save</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
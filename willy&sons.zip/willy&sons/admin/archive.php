<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Inventory</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="../js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/splidejs/4.1.4/css/splide-core.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <?php

    include '../config.php';
    include 'logout_modal.php';
    if(!isset($_SESSION['active_login'])){
      echo "<script>location.href='../index.php';</script>";
    }
  ?>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 250px; /* adjust width as needed */
  background: #c72429;
  color: #fff;
  padding-top: 20px;
  margin: 0; /* remove extra space */
  z-index: 1030; /* para laging nasa ibabaw */
}
  .sidebar .nav-link {
    color: #f1f1f1;
    font-weight: 500;
    border-radius: 6px;
    margin: 3px 8px;
    transition: all 0.2s;
  }

  .sidebar .nav-link i {
    color: #f8d7d7;
    transition: all 0.2s;
  }

  .sidebar .nav-link:hover {
    background: rgba(255, 255, 255, 0.2);
    color: #fff;
  }

  .sidebar .nav-link:hover i {
    color: #fff;
  }

  .active {
    background: #fff;
    color: #ff3300 !important;
    font-weight: 600;
  }

  .sidebar .nav-link.active i {
    color: #ff3300 !important;
  }
    .navbar {
      background-color: #fff;
      border-bottom: 1px solid #dee2e6;
    }
    .card {
      border-radius: 15px;
      border: none;
      box-shadow: 0 3px 6px rgba(0,0,0,0.05);
    }
    .status-badge {
      font-size: 0.8rem;
      padding: 3px 8px;
      border-radius: 12px;
      font-weight: 600;
    }
    .in-stock { background-color: #d1f7d1; color: #1c7c1c; }
    .low-stock { background-color: #fff3cd; color: #856404; }
    .out-stock { background-color: #f8d7da; color: #721c24; }
    .filter-btn.active {
      background-color: #ff6600 !important;
      color: #fff !important;
    }
 
    @media (max-width: 767px) {
      .sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
  <!-- Sidebar (desktop only) -->
     <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="text-center mb-4">
        <div class="d-flex align-items-center justify-content-center">
              <img src="../image/logo.png" alt="Logo" width="40" height="40" class="me-2">
              <h5 class="fw-bold mb-0">Willy & Sons</h5>
            </div>
            </div>
            <div class="nav flex-column">
              <a class="nav-link  d-flex align-items-center py-2" href="index.php">
                <i class="bi bi-speedometer2 fs-5 me-2"></i> <span>Dashboard</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2" href="orders.php">
                 <i class="bi bi-bag-check fs-5 me-2"></i> <span>Orders <div class="orders position-relative"></div></span>
              </a>
              <a class="nav-link  d-flex align-items-center py-2" href="inventory.php">
                <i class="bi bi-box-seam fs-5 me-2"></i> <span>Inventory</span>
              </a>
              <!--       <a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
              <a class="nav-link d-flex align-items-center py-2" href="customers.php">
                <i class="bi bi-people fs-5 me-2"></i> <span>Customers</span>
              </a>
               <a class="nav-link  active d-flex align-items-center py-2" href="archive.php">
                <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2 " href=""  data-bs-toggle="modal" data-bs-target="#logoutModal">
                <i class="bi bi-box-arrow-left fs-5 me-2"></i>  <span>Logout</span>
              </a>
            </div>
    </nav>

   <!-- Offcanvas Sidebar (mobile) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar">
      <div class="offcanvas-header">
        <h5 class="fw-bold text-danger">Willy & Sons</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body">
        <div class="nav flex-column">
          <a class="nav-link " href="index.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
          <a class="nav-link" href="orders.php"><i class="bi bi-bag-check me-2"></i> Orders <div class="orders position-relative"></div></a>
          <a class="nav-link " href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
          <!--<a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
          <a class="nav-link" href="customers.php"><i class="bi bi-people me-2"></i> Customers</a>
          <a class="nav-link active d-flex align-items-center py-2" href="archive.php">
            <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
          </a>
          <a class="nav-link" href="" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-left fs-5 me-2"></i>  Logout</a>
        </div>
      </div>
    </div>
    <!-- Main Content -->
    <main class="col-md-10 ms-sm-auto px-md-4">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
          <button class="btn d-md-none" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar">
            <i class="bi bi-list fs-3"></i>
          </button>
          <span class="navbar-text fw-semibold">Monitor and manage your product inventory</span>
          <div class="d-flex align-items-center">
          </div>
        </div>
      </nav>


      <!-- Filter -->
      <div class="d-flex flex-wrap align-items-center gap-2 mt-3 mb-3">
        <input type="text" class="form-control w-100" id="searchInput" placeholder="Search">
        <button class="btn btn-sm filter-btn active" data-category="all">All</button>
        <?php
          $get_category=$conn->prepare("SELECT * FROM `categories`");
          $get_category->execute();
          $result_cat = $get_category->get_result();
          if($result_cat->num_rows>0){
            while($row_cat = mysqli_fetch_assoc($result_cat)){
              $category_name = htmlspecialchars($row_cat['category_name']);
              ?>
              <button class="btn btn-sm filter-btn btn-outline-secondary" data-category="<?php echo $category_name; ?>"><?php echo $category_name; ?></button>
              <?php
            }
          }
        ?>
      </div>

      

      <!-- Products Inventory Table -->
      <div class="card p-3">
      
        
        <div class="table-responsive mt-3">
          <table class="table align-middle">
            <thead class="table-light">
              <tr>
                <th>Brand Name</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Status</th>
                <th>Stocks</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="productTable">
              <?php
              $status_data = 'Archive';
                $get_products = $conn->prepare("SELECT * FROM `products` WHERE `status` = ?");
                $get_products->bind_param("s",$status_data);
                $get_products->execute();
                $result_products = $get_products->get_result();
                if($result_products->num_rows>0){
                  while($row_cat = mysqli_fetch_assoc($result_products)){
                    $product_id = htmlspecialchars($row_cat['product_id']);
                    $product_name = htmlspecialchars($row_cat['product_name']);
                    $brand_name = htmlspecialchars($row_cat['brand_name']);
                    $category = htmlspecialchars($row_cat['category']);
                    $status = htmlspecialchars($row_cat['status']);
                    $price = htmlspecialchars($row_cat['price']);
                    $stocks = htmlspecialchars($row_cat['stocks']);


                  if ($status === "Active" && (int)$stocks > 0) {
                    $text = "🟢";
                    $style = "text-success p-1 m-0 fw-bold";
                    $data_text = "Active";
                } else {
                    $text = "🔴";
                    $style="text-danger  p-1  m-0 fw-bold";
                    $data_text = "Inactive";
                }
                 
                $get_category = $conn->prepare("SELECT * FROM `categories` WHERE `category_id` = ?");
                $get_category->bind_param("s",$category);
                $get_category->execute();
                $result_category = $get_category->get_result();
                if($result_category->num_rows>0){
                  while($row_category = mysqli_fetch_assoc($result_category)){
                    $category_name = htmlspecialchars($row_category['category_name']);
                   
              ?>
              <tr data-category="<?php echo $category_name; ?>">
                <td><?php echo $brand_name; ?></td>
                <td><?php echo $product_name; ?></td>
                <td><?php echo $category_name; ?></td>
                <td>₱ <?php echo $price; ?></td>
                <td><p class="<?php echo $style; ?>"><?php echo $text . $data_text; ?></p></td>
                <td><?php echo $stocks; ?></td>
                <td>
              
                  <a href="ask_restore.php?product_id=<?php  echo $product_id; ?>" class="btn text-success border-success"><i class="bi bi-arrow-clockwise text-success"></i> Restore</a><!--delete-->
                </td>
              </tr>
              <?php
                  }
                }
                  }
                }else{
                  echo "<tr><td colspan='7'>No Product Found</td></tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>


<?php     include '../alerts.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/splidejs/4.1.4/js/splide.min.js"></script>
<script src="../js/scripts.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>


  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var splide = new Splide('.splide', {
        type   : 'loop',
        perPage: 3,
        perMove: 1,
        arrows : false, 
      });

      splide.mount();
    });
  </script>
  <script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_orders.php", 
        method: "GET",
        success: function(response) {
            $('.orders').html(response);
        },
        error: function() {
            $('.orders').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>

  <script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_low_stocks.php", 
        method: "GET",
        success: function(response) {
            $('.pop_noti').html(response);
        },
        error: function() {
            $('.pop_noti').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>
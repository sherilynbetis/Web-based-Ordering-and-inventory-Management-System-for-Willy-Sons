<?php
    include 'archive.php';

    if(isset($_GET['product_id'])){
        $product_id =$_GET['product_id'];
    }
?>


<!-- Logout Modal -->
<form action="function.php" method="POST">
    <div class="modal fade" id="data" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header border-0">
        <h5 class="modal-title"> </h5>
      </div>
      <div class="modal-body text-center">
        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
        Are you sure you to Restore this Product?
      </div>
      <div class="modal-footer border-0">
            <button type="submit" name="restore_product" class="btn btn-success">Yes</button>
            <a href="archive.php" class="btn btn-secondary">No</a>
      </div>
    </div>
  </div>
</div>
</form>

<script>
document.addEventListener("DOMContentLoaded", function() {
  var myModal = new bootstrap.Modal(document.getElementById('data'));
  myModal.show();
});
</script>

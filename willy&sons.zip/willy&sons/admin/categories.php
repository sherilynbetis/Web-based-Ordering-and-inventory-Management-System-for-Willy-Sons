<?php 
    include 'inventory.php';
?>


<main>
    <section class="add-category-section">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" onclick="location.href='add_category.php'"  class="btn btn-primary" onclick="location.href='add_category.php'">Add</button>
                    <button type="button" onclick="location.href='inventory.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="overflow-auto">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Category Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $number = 1;
                                    $get =  $conn->prepare("SELECT * FROM `categories`");
                                    $get->execute();
                                    $result_cat = $get->get_result();
                                    if($result_cat->num_rows>0){
                                        while($row_cat = mysqli_fetch_assoc($result_cat)){
                                            $category_name = htmlspecialchars($row_cat['category_name']);
                                            $category_id = htmlspecialchars($row_cat['category_id']);
                                ?>
                                <tr>
                                    <td><?php echo $number; ?></td>
                                    <td><?php echo $category_name; ?></td>
                                    <td>
                                        <a href="delete_category.php?category_id=<?php echo $category_id; ?>"><i class="bi bi-trash text-danger"></i></a>
                                    </td>
                                </tr>
                                <?php
                                $number++;
                                         
                                        }
                                    }else{
                                        echo "<tr><td colspan='3'>No Categories Found</td></tr>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer border-0">

                </div>
                </div>
            </div>
            </div>
    </section>
</main>
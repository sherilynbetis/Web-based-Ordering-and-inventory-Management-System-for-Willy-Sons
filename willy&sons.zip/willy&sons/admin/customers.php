<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Inventory</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="../js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/splidejs/4.1.4/css/splide-core.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <?php
    include '../config.php';
    include 'logout_modal.php';
    if(!isset($_SESSION['active_login'])){
      echo "<script>location.href='../index.php';</script>";
          exit;
    }
  ?>
  <style>
    body { 
      background: #f8f9fa; 
      font-family: 'Segoe UI', sans-serif; 
    }

   .sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
    width: 250px; /* adjust width as needed */
  background: #c72429;
  color: #fff;
  padding-top: 20px;
  margin: 0; /* remove extra space */
  z-index: 1030; /* para laging nasa ibabaw */
}

    .sidebar .nav-link { 
      color: #f1f1f1; 
      font-weight: 500; 
      border-radius: 6px; 
      margin: 3px 8px; 
      transition: all 0.2s; 
    }

    .sidebar .nav-link i { 
      color: #f8d7d7; 
      transition: all 0.2s; 
    }

    .sidebar .nav-link:hover { 
      background: rgba(255, 255, 255, 0.2); 
      color: #fff; 
    }

    .sidebar .nav-link:hover i { 
      color: #fff; 
    }

    .active { 
      background: #fff; 
      color: #ff3300 !important; 
      font-weight: 600; 
    }

    .sidebar .nav-link.active i { 
      color: #ff3300 !important; 
    }

    .navbar { 
      background: #fff; 
      border-bottom: 1px solid #dee2e6; 
    }

    .card { 
      border-radius: 15px; 
      border: none; 
      box-shadow: 0 3px 6px rgba(0,0,0,0.05); 
    }

    .table img { 
      border-radius: 50%; 
    }

    .btn-action { 
      padding: 4px 8px; 
      border-radius: 6px; 
    }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar (desktop only) -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="text-center mb-4">
        <div class="d-flex align-items-center justify-content-center">
          <img src="../image/logo.jpg" alt="Logo" width="40" height="40" class="rounded-circle me-2">
          <h5 class="fw-bold mb-0">Willy & Sons</h5>
        </div>
      </div>
      <div class="nav flex-column">
        <a class="nav-link d-flex align-items-center py-2" href="index.php">
          <i class="bi bi-speedometer2 fs-5 me-2"></i> 
          <span>Dashboard</span>
        </a>
        <a class="nav-link d-flex align-items-center py-2" href="orders.php">
            <i class="bi bi-bag-check fs-5 me-2"></i> <span>Orders <div class="orders position-relative"></div></span>
        </a>
        <a class="nav-link d-flex align-items-center py-2" href="inventory.php">
          <i class="bi bi-box-seam fs-5 me-2"></i> 
          <span>Inventory</span>
        </a>
      <!--  <a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
        <a class="nav-link active d-flex align-items-center py-2" href="customers.php">
          <i class="bi bi-people fs-5 me-2"></i> 
          <span>Customers</span>
        </a>
         <a class="nav-link d-flex align-items-center py-2" href="archive.php">
            <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
          </a>
         <a class="nav-link d-flex align-items-center py-2 " href=""  data-bs-toggle="modal" data-bs-target="#logoutModal">
            <i class="bi bi-box-arrow-left fs-5 me-2"></i>  <span>Logout</span>
          </a>
      </div>
    </nav>

    <!-- Offcanvas mobile -->
    <div class="offcanvas offcanvas-start" id="offcanvasSidebar">
      <div class="offcanvas-header">
        <div class="d-flex align-items-center">
          <img src="../image/logo.jpg" alt="Logo" width="40" height="40" class="rounded-circle me-2">
          <h5 class="fw-bold mb-0 text-danger">Willy & Sons</h5>
        </div>
        <button class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link" href="orders.php"><i class="bi bi-bag-check me-2"></i> Orders  <div class="orders position-relative"></div></a>
        <a class="nav-link" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
        <!--<a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
        <a class="nav-link active" href="customers.php"><i class="bi bi-people me-2"></i> Customers</a>
        <a class="nav-link d-flex align-items-center py-2" href="archive.php">
            <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
          </a>
        <a class="nav-link" href="" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-left fs-5 me-2"></i>  Logout</a>
      </div>
    </div>

    <!-- Main Content -->
    <main class="col-md-10 ms-sm-auto px-md-4">
  <!-- Navbar -->
  <nav class="navbar px-3">
    <button class="btn d-md-none" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSidebar">
      <i class="bi bi-list fs-3"></i>
    </button>
    <div class="d-flex align-items-center w-100 justify-content-between">
      <span class="fw-semibold w-50">Customers Management</span>
      <form class="d-none d-md-flex w-100" method="GET">
        <input 
          type="text" 
          id="search_input"
          name="search_input" 
          class="form-control form-control-sm me-2 w-100" 
          placeholder="Search customers..." 
          value="<?php echo isset($_GET['search_input']) ? htmlspecialchars($_GET['search_input']) : ''; ?>">
      </form>
    </div>
  </nav>

  <!-- Customer List -->
  <div class="card p-3 mt-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="mb-0">Customer Accounts List</h5>
    </div>

    <div class="table-responsive">
      <table class="table align-middle">
        <thead class="table-light">
          <tr>
            <th>Avatar</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Total Orders</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody  id="customer_list">
          <?php
         
          $user_type = 'Customer';
          $search_input = isset($_GET['search_input']) ? trim($_GET['search_input']) : '';

   
          if (!empty($search_input)) {
              $search_term = "%{$search_input}%";
              $get_accounts = $conn->prepare("
                  SELECT * FROM `accounts` 
                  WHERE `user_type` = ? 
                  AND (`firstname` LIKE ? OR `lastname` LIKE ? OR `email` LIKE ? OR `phone_number` LIKE ?)
              ");
              $get_accounts->bind_param("sssss", $user_type, $search_term, $search_term, $search_term, $search_term);
          } else {
              // No search → show all
              $get_accounts = $conn->prepare("SELECT * FROM `accounts` WHERE `user_type` = ?");
              $get_accounts->bind_param("s", $user_type);
          }

          $get_accounts->execute();
          $result_accounts = $get_accounts->get_result();

          if ($result_accounts->num_rows > 0) {
              while ($row = $result_accounts->fetch_assoc()) {
                  $fullname = htmlspecialchars($row['lastname'] . ' ' . $row['firstname']);
                  $profile = htmlspecialchars($row['profile'] ?? '');
                  $email = htmlspecialchars($row['email'] ?? '');
                  $phone_number = htmlspecialchars($row['phone_number'] ?? '');
                  $user_id = htmlspecialchars($row['user_id'] ?? '');

            
                  $count_checkout = $conn->prepare("SELECT COUNT(*) AS total_checkout FROM `checkout` WHERE `user_id` = ?");
                  $count_checkout->bind_param("s", $user_id);
                  $count_checkout->execute();
                  $result_checkout = $count_checkout->get_result();
                  $total_checkout = $result_checkout->fetch_assoc()['total_checkout'] ?? 0;

                  $profile_path = ($profile === "") ? '../image/profile-icon.png' : "../uploads/$profile";
          ?>
              <tr>
                <td><img src="<?php echo $profile_path; ?>" class="rounded-circle" style="width:50px;aspect-ratio:1/1;"></td>
                <td><?php echo $fullname; ?></td>
                <td><?php echo $email; ?></td>
                <td><?php echo $phone_number; ?></td>
                <td><span class="badge bg-success"><?php echo $total_checkout; ?></span></td>
                <td><a href="customer_edit.php?user_id=<?php echo $user_id; ?>" class="btn btn-success"><i class="bi bi-three-dots"></i></a></td>
              </tr>
          <?php
              }
          } else {
              echo "<tr><td colspan='5' class='text-center text-muted'>No Customer Account found</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
    </main>

  </div>
</div>



<?php     include '../alerts.php'; ?>
<script src="../js/scripts.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
  <script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_orders.php", 
        method: "GET",
        success: function(response) {
            $('.orders').html(response);
        },
        error: function() {
            $('.orders').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>

<script>
document.getElementById("search_input").addEventListener("keyup", function() {
    let value = this.value;

    // AJAX
    let xhr = new XMLHttpRequest();
    xhr.open("GET", "fetch_customer.php?search=" + encodeURIComponent(value), true);

    xhr.onload = function() {
        if (this.status === 200) {
            document.getElementById("customer_list").innerHTML = this.responseText;
        }
    };

    xhr.send();
});
</script>

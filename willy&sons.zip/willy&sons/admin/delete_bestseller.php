<?php
 include 'inventory.php'; 
 if(isset($_GET['best_seller_id'])){
    $best_seller_id = $_GET['best_seller_id'] ?? '';
 }
 ?>



<main>
    <section class="delete-category-section">
        <form action="function.php" method="POST">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <input type="hidden" name="best_seller_id" value="<?php echo $best_seller_id; ?>">
                <div class="modal-header border-0">
                </div>
                <div class="modal-body">
                    Are You Sure To DELETE?
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="delete_bestseller" class="btn btn-danger">Yes</button>
                    <button type="button" onclick="location.href='best_seller.php'" class="btn btn-primary">No</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
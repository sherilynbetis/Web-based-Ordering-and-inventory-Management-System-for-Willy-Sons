<?php
 include 'inventory.php'; 
 if(isset($_GET['category_id'])){
    $category_id = $_GET['category_id'] ?? '';
 }
 ?>



<main>
    <section class="delete-category-section">
        <form action="function.php" method="POST">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <input type="hidden" name="category_id" value="<?php echo $category_id; ?>">
                <div class="modal-header border-0">
                </div>
                <div class="modal-body">
                    Are You Sure To DELETE?
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="delete_category" class="btn btn-danger">Yes</button>
                    <button type="button" onclick="location.href='categories.php'" class="btn btn-primary">No</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
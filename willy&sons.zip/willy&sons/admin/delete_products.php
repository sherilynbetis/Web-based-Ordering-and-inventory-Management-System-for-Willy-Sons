<?php
 include 'inventory.php';
  if(isset($_GET['product_id'])){
    $product_id = $_GET['product_id'] ?? '';
 }
 ?>



<main>
    <section class="delete-product-section">
        <form action="function.php" method="POST" enctype="multipart/form-data">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header border-0">
                </div>
                <div class="modal-body">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <p>Are Your Sure To Delete This Product?</p>
                </div>
            <div class="modal-footer  border-0">
                <input type="submit" name="delete_product" class="delete_products btn btn-danger" value="Delete Product">
                <input type="button" onclick="location.href='inventory.php'" value="Cancel" class="btn btn-secondary" name="" id="">
            </div>
            </div>
        </form>
    </section>
</main>
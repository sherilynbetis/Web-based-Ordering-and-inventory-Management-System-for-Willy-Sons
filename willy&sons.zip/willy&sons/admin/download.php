<?php
include '../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout Report</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .report-container {
      margin-top: 40px;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h3 {
      text-align: center;
      margin-bottom: 20px;
      font-weight: 700;
    }

    /* 🔹 Full-screen loading screen */
    #loadingScreen {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: #ffffff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }

    /* 🛒 Animated shopping cart */
    .cart-loader {
      position: relative;
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: #0d6efd22;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }

    .cart-loader::before {
      content: '';
      position: absolute;
      width: 40px;
      height: 25px;
      border: 3px solid #0d6efd;
      border-radius: 5px;
      transform: translateY(10px);
      animation: cart-bounce 1.2s infinite ease-in-out;
    }

    .cart-loader::after {
      content: '';
      position: absolute;
      bottom: 20px;
      left: 24px;
      width: 10px;
      height: 10px;
      background: #0d6efd;
      border-radius: 50%;
      box-shadow: 22px 0 #0d6efd;
      animation: wheel-spin 1.2s infinite linear;
    }

    @keyframes cart-bounce {
      0%, 100% { transform: translateY(10px); }
      50% { transform: translateY(-5px); }
    }

    @keyframes wheel-spin {
      0% { transform: rotate(0deg) translateY(0); }
      100% { transform: rotate(360deg) translateY(0); }
    }

    .loading-text {
      margin-top: 20px;
      font-size: 1.1rem;
      font-weight: 600;
      color: #0d6efd;
      text-align: center;
    }
  </style>
</head>
<body>

<!-- 🛒 Loading Screen -->
<div id="loadingScreen">
  <div class="cart-loader"></div>
  <div class="loading-text">Generating Checkout Report...</div>
</div>

<!-- 📊 Report Container -->
<div class="container report-container">
  <div id="reportContent">
    <h3>Checkout Report - Claimed</h3>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>Checkout ID</th>
          <th>Date</th>
          <th>Time</th>
          <th>Product ID</th>
          <th>Quantity</th>
          <th>Total</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $status = 'Claimed';
        $get_data = $conn->prepare("SELECT * FROM `checkout` WHERE `status` = ? ORDER BY `date` DESC");
        $get_data->bind_param("s", $status);
        $get_data->execute();
        $result_data = $get_data->get_result();

        if ($result_data->num_rows > 0) {
          while ($row_data = $result_data->fetch_assoc()) {
            $checkout_id = htmlspecialchars($row_data['checkout_id']);
            $date = htmlspecialchars($row_data['date']);
            $time = htmlspecialchars($row_data['time']);
            $product_id = htmlspecialchars($row_data['product_id']);
            $quantity = htmlspecialchars($row_data['quantity']);
            $total = number_format((float)$row_data['total'], 2);
            echo "
              <tr>
                <td>$checkout_id</td>
                <td>$date</td>
                <td>$time</td>
                <td>$product_id</td>
                <td>$quantity</td>
                <td>₱$total</td>
              </tr>
            ";
          }
        } else {
          echo "<tr><td colspan='6' class='text-center text-muted'>No data available</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  async function downloadPDF(tableId, filename) {
    const { jsPDF } = window.jspdf;
    const element = document.getElementById(tableId);
    const pdf = new jsPDF('p', 'pt', 'a4');
    const canvas = await html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    await pdf.save(filename + '.pdf');
  }

  window.onload = async () => {
    const loadingText = document.querySelector('.loading-text');
    loadingText.textContent = 'Preparing your report...';
    await downloadPDF('reportContent', 'Checkout_Report_<?php echo date("Y-m-d"); ?>');
    loadingText.textContent = 'Download complete! Redirecting...';
    document.getElementById('loadingScreen').style.display = 'none';
    setTimeout(() => {
      window.location.href = 'index.php';
    }, 1000);
  };
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

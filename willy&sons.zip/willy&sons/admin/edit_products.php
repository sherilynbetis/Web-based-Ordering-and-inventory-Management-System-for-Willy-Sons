<?php
 include 'inventory.php';
  if(isset($_GET['product_id'])){
    $product_id = $_GET['product_id'];
  }

  $get_rpoducts = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ? ");
  $get_rpoducts->bind_param("s",$product_id);
  $get_rpoducts->execute();
  $result_products = $get_rpoducts->get_result();
  if($result_products->num_rows>0){
    while($row_pro = mysqli_fetch_assoc($result_products)){
        $product_name = htmlspecialchars($row_pro['product_name']);
        $brand_name = htmlspecialchars($row_pro['brand_name']);
        $category = htmlspecialchars($row_pro['category']);
        $status = htmlspecialchars($row_pro['status']);
        $price = htmlspecialchars($row_pro['price']);
        $stocks = htmlspecialchars($row_pro['stocks']);
        $description = htmlspecialchars($row_pro['description']);
    }
  }


 
 ?>

<style>
.edit-product-section .featured-img{
    width:100%;
    aspect-ratio: 1/1;
}
</style>


<main>
    <section class="edit-product-section">
        <form action="function.php" method="POST" enctype="multipart/form-data">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <p class="fw-bold">EDIT PRODUCTS</p>
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <button type="button" onclick="location.href='inventory.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                   <div  id="my-slider" class="splide mb-3" aria-label="Splide Example">
                    <div class="splide__track">
                        <ul class="splide__list">
                        <?php
                        $get_images = $conn->prepare("SELECT * FROM `images` WHERE `product_id` = ?");
                        $get_images->bind_param("s", $product_id);
                        $get_images->execute();
                        $result_images = $get_images->get_result();
                        if ($result_images->num_rows > 0) {
                            while ($row_images = mysqli_fetch_assoc($result_images)) {
                            $image_name = htmlspecialchars($row_images['image_name']);
                            ?>
                            <li class="splide__slide">
                                <img src="../uploads/<?php echo $image_name; ?>" class="img-fluid featured-img" alt="">
                            </li>
                            <?php
                            }
                        }
                        ?>
                        </ul>
                    </div>
                    <input type="file" class="form-control" name="images[]" multiple accept=".jpg,jpeg,.png">
                    </div>
                    <div class="mb-3">
                        <label for="">Brand Name</label>
                        <input type="text" name="brand_name" class="form-control" value="<?php echo $brand_name;  ?>" placeholder="Enter Brand" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Product Name</label>
                        <input type="text" name="product_name" class="form-control" value="<?php echo $product_name;  ?>" placeholder="Enter Product" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Category</label>
                        <select name="category" id="" class="form-control" required>
                            <?php
                            
                                $get_category_id = $conn->prepare("SELECT * FROM `categories` WHERE `category_name` = ?");
                                $get_category_id->bind_param("s",$category);
                                $get_category_id->execute();
                                $result_cat = $get_category_id->get_result();
                                if($result_cat->num_rows>0){
                                    while($row_cat = mysqli_fetch_assoc($result_cat)){
                                        $category_ids = htmlspecialchars($row_cat['category_id'] ?? '');
                                        ?>
                                          <option value="<?php echo $category_ids ?? 'Select' ?>"><?php echo $category_ids ?? 'Select' ?></option>
                                        <?php
                                    }
                                }
                            ?>
                          
                            <?php
                            $get_cat = $conn->prepare("SELECT * FROM `categories`");
                            $get_cat->execute();
                            $result_cat = $get_cat->get_result();
                            if($result_cat->num_rows>0){
                                while($row_cat = mysqli_fetch_assoc($result_cat)){
                                    $category_name = htmlspecialchars($row_cat['category_name']);
                                    $category_id  = htmlspecialchars($row_cat['category_id']);
                                    ?>
                                    <option value="<?php echo $category_id; ?>"><?php echo $category_name; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="">Status</label>
                        <select name="status" id="" class="form-control">
                            <option value="<?php echo $status ?? 'Select'; ?>"><?php echo $status ?? 'Select'; ?></option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Discontinued">Discontinued</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="">Price</label>
                        <input type="number" name="price" class="form-control" value="<?php echo $price ?? '';  ?>" placeholder="Enter Price" required>
                    </div>
                    <div class="mb-3">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control p-2" id=""><?php echo  $description ?? '';  ?></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0">
                     <button type="submit" name="archive_product" class="btn btn-danger">Archive</button>
                    <button type="submit" name="edit_product" class="btn btn-primary">Update</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
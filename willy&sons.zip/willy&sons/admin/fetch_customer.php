<?php
include '../config.php'; 

$user_type = 'Customer';
$search_input = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search_input)) {
    $search_term = "%{$search_input}%";
    $get_accounts = $conn->prepare("
        SELECT * FROM `accounts`
        WHERE `user_type` = ?
        AND (`firstname` LIKE ? OR `lastname` LIKE ? OR `email` LIKE ? OR `phone_number` LIKE ?)
    ");
    $get_accounts->bind_param("sssss", $user_type, $search_term, $search_term, $search_term, $search_term);
} else {
    $get_accounts = $conn->prepare("SELECT * FROM `accounts` WHERE `user_type` = ?");
    $get_accounts->bind_param("s", $user_type);
}

$get_accounts->execute();
$result_accounts = $get_accounts->get_result();

if ($result_accounts->num_rows > 0) {
    while ($row = $result_accounts->fetch_assoc()) {

        $fullname = htmlspecialchars($row['lastname'] . ' ' . $row['firstname']);
        $profile = htmlspecialchars($row['profile'] ?? '');
        $email = htmlspecialchars($row['email'] ?? '');
        $phone_number = htmlspecialchars($row['phone_number'] ?? '');
        $user_id = htmlspecialchars($row['user_id'] ?? '');

        $count_checkout = $conn->prepare("SELECT COUNT(*) AS total_checkout FROM checkout WHERE user_id = ?");
        $count_checkout->bind_param("s", $user_id);
        $count_checkout->execute();
        $result_checkout = $count_checkout->get_result();
        $total_checkout = $result_checkout->fetch_assoc()['total_checkout'] ?? 0;

        $profile_path = ($profile === "") ? '../image/profile-icon.png' : "../uploads/$profile";

        echo "
        <tr>
            <td><img src='$profile_path' class='rounded-circle' style='width:50px;aspect-ratio:1/1;'></td>
            <td>$fullname</td>
            <td>$email</td>
            <td>$phone_number</td>
            <td><span class='badge bg-success'>$total_checkout</span></td>
            <td><a href='customer_edit.php?user_id=<?php echo $user_id; ?>' class='btn btn-success'><i class='bi bi-three-dots'></i></a></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='6' class='text-center text-muted'>No Customer Account found</td></tr>";
}

<?php
include '../config.php';

$status = 'Active';
$stock = 5;

$get_low_stocks = $conn->prepare("SELECT COUNT(*) as `total_stocks` FROM `products` WHERE `status` = ? AND `stocks` <= ?");
$get_low_stocks->bind_param("si", $status, $stock);
$get_low_stocks->execute();
$result_stocks = $get_low_stocks->get_result();

if ($result_stocks->num_rows > 0) {
    while ($row_stocks = mysqli_fetch_assoc($result_stocks)) {
        $total_stocks = htmlspecialchars($row_stocks['total_stocks'] ?? 0);
        echo "<h6 class='position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger'>$total_stocks</h6>";
    }
}
?>


<?php
    include '../config.php';
    $status = "Pending";
    $checkout = $conn->prepare("SELECT COUNT(*) as `total_orders` FROM `checkout` WHERE `status` = ?");
    $checkout->bind_param("s",$status);
    $checkout->execute();
    $result_orders = $checkout->get_result();
    if($result_orders->num_rows>0){
        while($row_count = mysqli_fetch_assoc($result_orders)){
            $total_orders = htmlspecialchars($row_count['total_orders'] ?? 0);
        }
    }

    
 ?>

 <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
    <?php echo $total_orders; ?>
  </span>
<?php

include '../config.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../email-sender/src/Exception.php';
require '../email-sender/src/PHPMailer.php';
require '../email-sender/src/SMTP.php';

if(isset($_POST['save_categories'])){
    $category_name = $_POST['category_name'];

    $same = $conn->prepare("SELECT * FROM `categories` WHERE `category_name` =?");
    $same->bind_param("s",$category_name);
    $same->execute();
    $result_category = $same->get_result();
    if($result_category->num_rows>0){
        $_SESSION['warning'] = "Category Already Inserted";
        header("location:add_category.php");
        exit;
    }

    $category_id = rand();
    $insert = $conn->prepare("INSERT INTO `categories` (`category_id`,`category_name`) VALUES (?,?)");
    $insert->bind_param("ss",$category_id,$category_name);
    $insert->execute();

    $_SESSION['success'] = "Successfully Inserted";
    header("location:categories.php");
    exit;
}

if(isset($_POST['delete_category'])){
    $category_id = $_POST['category_id'];

    $delete=  $conn->prepare("DELETE FROM `categories` WHERE `category_id` = ?");
    $delete->bind_param("s",$category_id);
    $delete->execute();
    $_SESSION['success'] = "Successfully Deleted";
    header("location:categories.php");
    exit;
}

if (isset($_POST['save_product'])) {
    $brand_name   = $_POST['brand_name'];
    $product_name = $_POST['product_name'];
    $category     = $_POST['category'];
    $status       = $_POST['status'];
    $price        = $_POST['price'];
    $description        = $_POST['description'];


    $_SESSION['brand_name']   = $brand_name;
    $_SESSION['product_name'] = $product_name;
    $_SESSION['category']     = $category;
    $_SESSION['status']       = $status;
    $_SESSION['price']        = $price;
    $_SESSION['description']  = $description;


    // check duplicate
    $get_productname = $conn->prepare("SELECT * FROM `products` WHERE `product_name` = ? AND `brand_name` = ?");
    $get_productname->bind_param("ss", $product_name, $brand_name);
    $get_productname->execute();
    $result_products = $get_productname->get_result();

    if ($result_products->num_rows > 0) {
        $_SESSION['warning'] = "Product Name Already Inserted";
        header("location:add_product.php");
        exit;
    } elseif ($status === 'Select') {
        $_SESSION['error'] = "Invalid Status";
        header("location:add_product.php");
        exit;
    } elseif ($category === 'Select') {
        $_SESSION['error'] = "Invalid Category";
        header("location:add_product.php");
        exit;
    } else {
        $product_id = rand() . uniqid();

        // handle images upload
        if (!empty($_FILES['images']['name'][0])) {
            foreach ($_FILES['images']['name'] as $key => $image_name) {
                $tmp_name   = $_FILES['images']['tmp_name'][$key];
                $destination = '../uploads/' . basename($image_name);

                if (move_uploaded_file($tmp_name, $destination)) {
                    $image_id = rand();
                    $insert_img = $conn->prepare("INSERT INTO `images` (`image_id`, `image_name`, `product_id`) VALUES (?,?,?)");
                    $insert_img->bind_param("sss", $image_id, $image_name, $product_id);
                    $insert_img->execute();
                }
            }
        }

        // insert product
        $insert_products = $conn->prepare("INSERT INTO `products` 
            (`product_id`, `product_name`, `brand_name`, `category`, `status`, `price`,`description`) 
            VALUES (?,?,?,?,?,?,?)");
        $insert_products->bind_param("sssssss", $product_id, $product_name, $brand_name, $category, $status, $price,$description);
        $insert_products->execute();

        // clear session temp values
        unset($_SESSION['brand_name']);
        unset($_SESSION['product_name']);
        unset($_SESSION['category']);
        unset($_SESSION['status']);
        unset($_SESSION['price']);
        unset($_SESSION['description']);


        $_SESSION['success'] = "Successfully Inserted";
        header("location:inventory.php");
        exit;
    }
}

if(isset($_POST['edit_product'])){
    $brand_name   = $_POST['brand_name'];
    $product_name = $_POST['product_name'];
    $category     = $_POST['category']; // check if this is ID or Name
    $status       = $_POST['status'];
    $price        = $_POST['price'];
    $description        = $_POST['description'];
   
    $product_id   = $_POST['product_id'];

    // check duplicate
    $get_productname = $conn->prepare("SELECT * FROM `products` WHERE `product_name` = ? AND `brand_name` = ? AND `product_id` != ?");
    $get_productname->bind_param("sss", $product_name, $brand_name, $product_id);
    $get_productname->execute();
    $result_products = $get_productname->get_result();

    if ($result_products->num_rows > 0) {
        $_SESSION['warning'] = "Product Name Already Inserted";
        header("location:edit_products.php?product_id=$product_id");
        exit;
    } elseif ($status === 'Select') {
        $_SESSION['error'] = "Invalid Status";
        header("location:edit_products.php?product_id=$product_id");
        exit;
    } elseif ($category === 'Select') {
        $_SESSION['error'] = "Invalid Category";
        header("location:edit_products.php?product_id=$product_id");
        exit;
    } else {

        // only delete and re-insert images if new ones are uploaded
        // handle images upload
        if (!empty($_FILES['images']['name'][0])) {
            // Delete old images first
            $delete = $conn->prepare("DELETE FROM `images` WHERE `product_id` = ?");
            $delete->bind_param("s", $product_id);
            $delete->execute();

            foreach ($_FILES['images']['name'] as $key => $image_name) {
                $tmp_name   = $_FILES['images']['tmp_name'][$key];
                $destination = '../uploads/' . basename($image_name);

                if (move_uploaded_file($tmp_name, $destination)) {
                    $image_id = rand();
                    $insert_img = $conn->prepare("INSERT INTO `images` (`image_id`, `image_name`, `product_id`) VALUES (?,?,?)");
                    $insert_img->bind_param("sss", $image_id, $image_name, $product_id);
                    $insert_img->execute();
                }
            }
        }


        $update = $conn->prepare("UPDATE `products` SET `product_name` = ?, `brand_name` = ?, `category` = ?, `status` = ?, `price` = ?, `description` = ? WHERE `product_id` = ?");
        $update->bind_param("sssssss", $product_name, $brand_name, $category, $status, $price,$description,$product_id);
        $update->execute();

        $_SESSION['success'] = "Successfully Updated"; 
        header("location:inventory.php");
        exit;
    }
}


if(isset($_POST['delete_product'])){
    $product_id = $_POST['product_id'];

    $delete_products = $conn->prepare("DELETE FROM `products` WHERE `product_id` = ?");
    $delete_products->bind_param("s",$product_id);
    $delete_products->execute();


    $delete_images = $conn->prepare("DELETE FROM `images` WHERE `product_id` = ?");
    $delete_images->bind_param("s",$product_id);
    $delete_images->execute();

    $_SESSION['success'] = "Successfully Deleted";
    header("location:inventory.php");
    exit;
}

if (isset($_POST['save_bestseller'])) {
    if (!empty($_POST['products'])) {
        $products = $_POST['products'];
        $errors = [];
        $inserted = [];

        foreach ($products as $allproducts) {
            $get = $conn->prepare("SELECT * FROM `best_seller` WHERE `product_id` = ?");
            $get->bind_param("s", $allproducts);
            $get->execute();
            $result_products = $get->get_result();

            if ($result_products->num_rows > 0) {
                $errors[] = "Product ID $allproducts already inserted.";
            } else {
                $best_seller_id = rand();
                $insert = $conn->prepare("INSERT INTO `best_seller` (`best_seller_id`,`product_id`) VALUES (?,?)");
                $insert->bind_param("ss", $best_seller_id, $allproducts);
                $insert->execute();
                $inserted[] = $allproducts;
            }
        }

        if (!empty($inserted)) {
            $_SESSION['success'] = count($inserted) . " product(s) successfully inserted.";
        }
        if (!empty($errors)) {
            $_SESSION['error'] = implode("<br>", $errors);
        }
    } else {
        $_SESSION['error'] = "No products selected.";
    }

  
    header("location:add_best_seller.php");
    exit;
}


if(isset($_POST['delete_bestseller'])){
     $best_seller_id = $_POST['best_seller_id'];

    $delete_products = $conn->prepare("DELETE FROM `best_seller` WHERE `best_seller_id` = ?");
    $delete_products->bind_param("s",$best_seller_id);
    $delete_products->execute();


    $_SESSION['success'] = "Successfully Deleted";
    header("location:best_seller.php");
    exit;
}

if (isset($_POST['approved_order'])) {
    $checkout_id = $_POST['checkout_id'];
    $email = $_POST['email'];
     $fullname = $_POST['fullname'];

     $checkout_get =  $conn->prepare("SELECT * FROM `checkout` WHERE `checkout_id` = ?");
    $checkout_get->bind_param("s",$checkout_id);
    $checkout_get->execute();
    $result_check = $checkout_get->get_result();
    if($result_check->num_rows>0){
        while($row_check = mysqli_fetch_assoc($result_check)){
            $quantity = htmlspecialchars($row_check['quantity']);
            $product_id = htmlspecialchars($row_check['product_id']);
        }
    }

     $get_stocks = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get_stocks->bind_param("s",$product_id);
    $get_stocks->execute();
    $result_stocks = $get_stocks->get_result();
    if($result_stocks->num_rows>0){
        while($row_stocks = mysqli_fetch_assoc($result_stocks)){
            $stocks = htmlspecialchars($row_stocks['stocks']);
        }
    }

    if($stocks === 0){
        $_SESSION['error'] = "0 Product stocks";
        header("Location: orders.php");
        exit;
    }
    elseif($quantity > $stocks ){
        $_SESSION['error'] = "Quantity is Higher Than Stocks";
        header("Location: orders.php");
        exit;
    }else{


    $nextday = date('m/d/Y', strtotime($datetoday . ' +1 day'));



    $subject = "Willy & Sons Approved Order";
    $message = "
        <p>Dear <strong>$fullname</strong>,</p>

        <p>We are pleased to inform you that your order has been <strong>approved</strong>! 🎉</p>

        <p>Please proceed to <strong>Willy & Sons Bulan</strong> to <strong>claim and pick up</strong> your order within <strong>24 hours</strong>.  
        Failure to do so may result in your order being cancelled.</p>

        <p>Thank you for choosing <strong>Willy & Sons</strong>. We appreciate your trust and look forward to serving you again.</p>

        <br>
        <p>Best regards,</p>
        <p><strong>Willy & Sons Bulan Team</strong></p>
    ";

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->SMTPAuth = true;
        $mail->Username = 'willyandsonsbulan@gmail.com';
        $mail->Password = 'efzy frsw wfup szbz'; // app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('willyandsonsbulan@gmail.com', 'Willy & Sons');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send email
        $mail->send();

        // Update database
        $status = 'Approved';
        $update = $conn->prepare("UPDATE checkout SET `status`=?, `expiration_date`=?, `expiration_time`=? WHERE `checkout_id`=?");
        $update->bind_param("ssss", $status, $nextday, $timetoday, $checkout_id);
        $update->execute();

        $_SESSION['success'] = "Successfully Updated";
        header("Location: orders.php");
        exit;

    } catch (Exception $e) {
        $_SESSION['error'] = "Slow / No Internet, please check your connection!";
        header("Location: orders.php");
        exit;
    }
            
    }


}


if(isset($_POST['disapproved_order'])){
    $checkout_id = $_POST['checkout_id'];
    $email = $_POST['email'];
     $fullname = $_POST['fullname'];



    $nextday = date('m/d/Y', strtotime($datetoday . ' +1 day'));



    $subject = "Willy & Sons Approved Order";
    $message = "
        <p>Dear <strong>$fullname</strong>,</p>

        <p>We are Sorry to inform you that your order has been <strong>Disapproved</strong>! 🎉</p>


        <p>Thank you for choosing <strong>Willy & Sons</strong>. We appreciate your trust and look forward to serving you again.</p>

        <br>
        <p>Best regards,</p>
        <p><strong>Willy & Sons Bulan Team</strong></p>
    ";

    $mail = new PHPMailer(true);

    try {
               $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        $mail->SMTPAuth = true;
        $mail->Username = 'willyandsonsbulan@gmail.com';
        $mail->Password = 'efzy frsw wfup szbz'; // app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('willyandsonsbulan@gmail.com', 'Willy & Sons');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send email
        $mail->send();

        // Update database
        $status = 'Disapproved';
        $update = $conn->prepare("UPDATE checkout SET `status`=?, `expiration_date`=?, `expiration_time`=? WHERE `checkout_id`=?");
        $update->bind_param("ssss", $status, $nextday, $timetoday, $checkout_id);
        $update->execute();

        $_SESSION['success'] = "Successfully Updated";
        header("Location: orders.php");
        exit;

    } catch (Exception $e) {
        $_SESSION['error'] = "Slow / No Internet, please check your connection!";
        header("Location: orders.php");
        exit;
    }
}

if(isset($_POST['claimed_order'])){
    $checkout_id = $_POST['checkout_id'];
    $status = 'Claimed';

    $checkout_get =  $conn->prepare("SELECT * FROM `checkout` WHERE `checkout_id` = ?");
    $checkout_get->bind_param("s",$checkout_id);
    $checkout_get->execute();
    $result_check = $checkout_get->get_result();
    if($result_check->num_rows>0){
        while($row_check = mysqli_fetch_assoc($result_check)){
            $quantity = htmlspecialchars($row_check['quantity']);
            $product_id = htmlspecialchars($row_check['product_id']);
        }
    }


    $get_stocks = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get_stocks->bind_param("s",$product_id);
    $get_stocks->execute();
    $result_stocks = $get_stocks->get_result();
    if($result_stocks->num_rows>0){
        while($row_stocks = mysqli_fetch_assoc($result_stocks)){
            $stocks = htmlspecialchars($row_stocks['stocks']);
        }
    }
    if((int)$stocks === 0){
         $_SESSION['error'] = "0 stocks";
        header("Location: orders.php");
        exit;
    }
    elseif($quantity > $stocks){
        $_SESSION['error'] = "Quantity is Higher than Stocks";
        header("Location: orders.php");
        exit;
    }else{
        $updated_stocks = (float)$stocks  -  (float)$quantity;
        $update_stocks =  $conn->prepare("UPDATE `products` SET `stocks` = ? WHERE `product_id` = ?");
        $update_stocks->bind_param("ss",$updated_stocks,$product_id);
        $update_stocks->execute();

        $update = $conn->prepare("UPDATE checkout SET `status`=? WHERE `checkout_id`=?");
        $update->bind_param("ss", $status,  $checkout_id);
        $update->execute();

        $log_id = rand();
        $action = "Order Claimed";
        $type = "Order";
        $insert_log = $conn->prepare("INSERT INTO `logs` (`log_id`,`action`,`date`,`type`) VALUES (?,?,?,?)");
        $insert_log->bind_param("ssss", $log_id, $action, $datetoday, $type);
        $insert_log->execute();

        $_SESSION['success'] = "Successfully Updated";
        header("Location: orders.php");
        exit;
    }
  

}

if(isset($_POST['unclaimed_order'])){
    $checkout_id = $_POST['checkout_id'];
    $status = 'Unclaimed';
    $update = $conn->prepare("UPDATE checkout SET `status`=? WHERE `checkout_id`=?");
    $update->bind_param("ssss", $status,  $checkout_id);
    $update->execute();

    $_SESSION['success'] = "Successfully Updated";
    header("Location: orders.php");
    exit;

}


if (isset($_POST['stock_in'])) {
    $stocks = (int)$_POST['stocks']; 
    $product_id = $_POST['product_id'];


    $get_info = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get_info->bind_param("s", $product_id);
    $get_info->execute();
    $result_products = $get_info->get_result();

    if ($result_products->num_rows > 0) {
        $row_products = $result_products->fetch_assoc();
        $product_name = htmlspecialchars($row_products['product_name']);
        $stocks_before = (int)$row_products['stocks'];
    } else {
        $_SESSION['error'] = "Product not found.";
        header("location:stockin.php");
        exit;
    }


    $new_stocks = (float)$stocks_before + (float)$stocks;


    if ($new_stocks < 0) {
        $new_stocks = 0;
    }

 
    $update = $conn->prepare("UPDATE `products` SET `stocks` = ? WHERE `product_id` = ?");
    $update->bind_param("is", $new_stocks, $product_id);
    $update->execute();

   
    $log_id = rand();
    $action = "Added $stocks to $product_name (New total: $new_stocks)";
    $type = "Stock In";
    $insert_log = $conn->prepare("INSERT INTO `logs` (`log_id`,`action`,`date`,`type`) VALUES (?,?,?,?)");
    $insert_log->bind_param("ssss", $log_id, $action, $datetoday, $type);
    $insert_log->execute();

    $_SESSION['success'] = "Successfully updated stock.";
    header("location:stockin.php");
    exit;
}



if (isset($_POST['stock_out'])) {
    $stocks = (int)$_POST['stocks'];
    $product_id = $_POST['product_id'];


    $get_info = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get_info->bind_param("s", $product_id);
    $get_info->execute();
    $result_products = $get_info->get_result();

    if ($result_products->num_rows > 0) {
        $row_products = $result_products->fetch_assoc();
        $product_name = htmlspecialchars($row_products['product_name']);
        $stocks_before = (int)$row_products['stocks'];
    } else {
        $_SESSION['error'] = "Product not found.";
        header("location:stockin.php");
        exit;
    }


    $new_stocks = (float)$stocks_before - (float)$stocks;


    if ($new_stocks < 0) {
        $new_stocks = 0;
    }

  
    $update = $conn->prepare("UPDATE `products` SET `stocks` = ? WHERE `product_id` = ?");
    $update->bind_param("is", $new_stocks, $product_id);
    $update->execute();


    $log_id = rand();
    $action = "Subtracted $stocks from $product_name (New total: $new_stocks)";
    $type = "Stock Out";
    $insert_log = $conn->prepare("INSERT INTO `logs` (`log_id`,`action`,`date`,`type`) VALUES (?,?,?,?)");
    $insert_log->bind_param("ssss", $log_id, $action, $datetoday, $type);
    $insert_log->execute();

    $_SESSION['success'] = "Successfully updated stock.";
    header("location:stockin.php");
    exit;
}


if (isset($_POST['update_info'])) {
    $lastname     = $_POST['lastname'];
    $firstname    = $_POST['firstname'];
    $phone_number = $_POST['phone_number'];
    $email        = $_POST['email'];
    $address      = $_POST['address'];
    $street       = $_POST['street'];
    $purok        = $_POST['purok'];
    $user_id        = $_POST['user_id'];

    $profile     = $_FILES['profile']['name'] ?? '';
    $profile_tmp = $_FILES['profile']['tmp_name'] ?? '';
    $destination = '../uploads/' . $profile;

    // ✅ Check duplicate email
    $get_email = $conn->prepare("SELECT * FROM `accounts` WHERE `email` = ? AND `user_id` != ?");
    $get_email->bind_param("ss", $email, $user_id);
    $get_email->execute();
    if ($get_email->get_result()->num_rows > 0) {
        $_SESSION['error'] = "Email Already Taken";
        header("location:customer_edit.php?user_id=$user_id");
        exit;
    }

    // ✅ Check duplicate phone
    $get_number = $conn->prepare("SELECT * FROM `accounts` WHERE `phone_number` = ? AND `user_id` != ?");
    $get_number->bind_param("ss", $phone_number, $user_id);
    $get_number->execute();
    if ($get_number->get_result()->num_rows > 0) {
        $_SESSION['error'] = "Phone Number Already Taken";
         header("location:customer_edit.php?user_id=$user_id");
        exit;
    }

    // ✅ If profile uploaded
    if (!empty($profile) && move_uploaded_file($profile_tmp, $destination)) {
        $update = $conn->prepare("UPDATE `accounts` 
            SET `lastname`=?, `firstname`=?, `phone_number`=?, `email`=?, 
                `profile`=?, `address`=?, `street`=?, `purok`=? 
            WHERE `user_id`=?");
        $update->bind_param("sssssssss", $lastname, $firstname, $phone_number, $email, $profile, $address, $street, $purok, $user_id);
    } else {
        // ✅ Update without profile
        $update = $conn->prepare("UPDATE `accounts` 
            SET `lastname`=?, `firstname`=?, `phone_number`=?, `email`=?, 
                `address`=?, `street`=?, `purok`=? 
            WHERE `user_id`=?");
        $update->bind_param("ssssssss", $lastname, $firstname, $phone_number, $email, $address, $street, $purok, $user_id);
    }

    $update->execute();
    $_SESSION['success'] = "Successfully Updated";
    header("location:customers.php");
    exit;
}



if(isset($_POST['block_user'])){
    $user_id = $_POST['user_id'];
 echo $user_id;
}


if(isset($_POST['unblock_user'])){
     $user_id = $_POST['user_id'];
    $status = 'Active';
    $update = $conn->prepare("UPDATE `accounts` SET `status` =? WHERE `user_id` = ?");
    $update->bind_param("ss",$status,$user_id);
    $update->execute();
    $_SESSION['success'] = "Successfully Unblocked";
    header("location:customers.php");
    exit;
}


if(isset($_POST['archive_product'])){
    $product_id = $_POST['product_id'];
    $status = 'Archive';
    $update =  $conn->prepare("UPDATE `products` SET `status` = ? WHERE `product_id` = ?");
    $update->bind_param("ss",$status,$product_id);
    $update->execute();
    $_SESSION['sucess'] = "Successfully Updated";
    header("location:inventory.php");
    exit;
}

if(isset($_POST['restore_product'])){
     $product_id = $_POST['product_id'];
    $status = 'Active';
    $update =  $conn->prepare("UPDATE `products` SET `status` = ? WHERE `product_id` = ?");
    $update->bind_param("ss",$status,$product_id);
    $update->execute();
    $_SESSION['sucess'] = "Successfully Updated";
    header("location:archive.php");
    exit;
}
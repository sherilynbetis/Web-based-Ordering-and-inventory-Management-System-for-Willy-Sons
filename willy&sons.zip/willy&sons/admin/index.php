<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Dashboard</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <?php

    include '../config.php';
    include 'logout_modal.php';
    if(!isset($_SESSION['active_login'])){
  echo "<script>location.href='../index.php';</script>";
    exit;
}
  ?>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fc;
    }
    /* Sidebar (desktop) */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 250px; /* adjust width as needed */
  background: #c72429;
  color: #fff;
  padding-top: 20px;
  margin: 0; /* remove extra space */
  z-index: 1030; /* para laging nasa ibabaw */
}


  .sidebar .nav-link {
    color: #f1f1f1;
    font-weight: 500;
    border-radius: 6px;
    margin: 3px 8px;
    transition: all 0.2s;
  }

  .sidebar .nav-link i {
    color: #f8d7d7;
    transition: all 0.2s;
  }

  .sidebar .nav-link:hover {
    background: rgba(255, 255, 255, 0.2);
    color: #fff;
  }

  .sidebar .nav-link:hover i {
    color: #fff;
  }

 .active {
    background: #fff;
    color: #ff3300 !important;
    font-weight: 600;
  }

  .sidebar .nav-link.active i {
    color: #ff3300 !important;
  }
    /* Stats Cards */
    .stat-card {
      border-radius: 12px;
      border: 1px solid #eee;
      background: #fff;
      padding: 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .stat-card .icon-box {
      font-size: 2rem;
      padding: 12px;
      border-radius: 12px;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .orders-icon { background-color: #007bff; }
    .revenue-icon { background-color: #28a745; }
    .products-icon { background-color: #ff9800; }
    .lowstock-icon { background-color: #dc3545; }

    /* Status badges */
    .status-badge {
      font-size: 0.8rem;
      padding: 3px 8px;
      border-radius: 12px;
      font-weight: 600;
    }
    .completed { background-color: #d4edda; color: #155724; }
    .processing { background-color: #cce5ff; color: #004085; }
    .shipped { background-color: #fff3cd; color: #856404; }
    .pending { background-color: #f8d7da; color: #721c24; }

    /* Hide sidebar in mobile (use offcanvas instead) */
    @media (max-width: 767.98px) {
      .sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>

<!-- Navbar (Top) -->
<nav class="navbar navbar-light bg-white border-bottom sticky-top">
  <div class="container-fluid">
    <!-- Burger button (mobile only) -->
    <button class="btn btn-outline-secondary d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar">
      <i class="bi bi-list"></i>
    </button>    
</nav>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar (desktop only) -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="text-center mb-4">
        <div class="d-flex align-items-center justify-content-center">
              <img src="../image/logo.png" alt="Logo" width="40" height="40" class="me-2">
              <h5 class="fw-bold mb-0">Willy & Sons</h5>
            </div>
            </div>
            <div class="nav flex-column">
              <a class="nav-link active d-flex align-items-center py-2" href="index.php">
                <i class="bi bi-speedometer2 fs-5 me-2"></i> <span>Dashboard</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2" href="orders.php">
                <i class="bi bi-bag-check fs-5 me-2"></i> <span>Orders <div class="orders position-relative"></div></span>
              </a>
              <a class="nav-link d-flex align-items-center py-2" href="inventory.php">
                <i class="bi bi-box-seam fs-5 me-2"></i> <span>Inventory</span>
              </a>
               <!--<a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
              <a class="nav-link d-flex align-items-center py-2" href="customers.php">
                <i class="bi bi-people fs-5 me-2"></i> <span>Customers</span>
              </a>
               <a class="nav-link d-flex align-items-center py-2" href="customers.php">
                <i class="bi bi-people fs-5 me-2"></i> <span>Customers</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2" href="archive.php">
                <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2 " href=""  data-bs-toggle="modal" data-bs-target="#logoutModal">
                <i class="bi bi-box-arrow-left fs-5 me-2"></i>  <span>Logout</span>
              </a>
            </div>
    </nav>
    

    <!-- Offcanvas Sidebar (mobile) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar">
      <div class="offcanvas-header">
        <h5 class="fw-bold text-danger">Willy & Sons</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body">
        <div class="nav flex-column">
          <a class="nav-link active" href="index.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
          <a class="nav-link" href="orders.php"><i class="bi bi-bag-check me-2"></i> Orders  <div class="orders position-relative"></div></a>
          <a class="nav-link" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
         <!-- <a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
          <a class="nav-link" href="customers.php"><i class="bi bi-people me-2"></i> Customers</a>
          <a class="nav-link d-flex align-items-center py-2" href="archive.php">
            <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
          </a>
          <a class="nav-link" href="" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-left fs-5 me-2"></i>  Logout</a>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <main class="col-md-10 ms-sm-auto px-md-4 mt-3">
      <!-- Stats Cards -->
       <div class="row">
          <div class="col-lg-8">
            <div class="row my-4">
              <div class="col-md-4 mb-3">
                <div class="stat-card">
                  <div>
                    <?php
                      $Claimed = 'Claimed';
                      $count = $conn->prepare("SELECT COUNT(*) as `total_order` FROM `checkout` WHERE `status` = ?");
                      $count->bind_param("s",$Claimed);
                      $count->execute();
                      $result_count= $count->get_result();
                      if($result_count->num_rows>0){
                        while($row_count = mysqli_fetch_assoc($result_count)){
                          $total_order = htmlspecialchars($row_count['total_order'] ?? 0);
                        }
                      }
                    ?>
                    <h4><?php echo $total_order; ?></h4>
                    <p class="mb-0">Total Orders</p>
                  </div>
                  <div class="icon-box orders-icon"><i class="bi bi-cart"></i></div>
                </div>
              </div>
              <div class="col-md-4 mb-3">
                <div class="stat-card">
                  <div>
                    <?php
                    $count_products = $conn->prepare("SELECT COUNT(*) as `total_products` FROM `products` ");
                    $count_products->execute();
                    $result_products = $count_products->get_result();
                    if($result_products->num_rows>0){
                      while($row_products = mysqli_fetch_assoc($result_products)){
                        $total_products = htmlspecialchars($row_products['total_products'] ?? 0);
                      }
                    }
                    ?>
                    <h4><?php echo $total_products; ?></h4>
                    <p class="mb-0">Products</p>
                  </div>
                  <div class="icon-box products-icon"><i class="bi bi-box"></i></div>
                </div>
              </div>
              <div class="col-md-4 mb-3">
                <div class="stat-card">
                  <div>
                    <?php 
                    $stocks = 5;
                    $count_low_stocks = $conn->prepare("SELECT COUNT(*) as `low_stocks` FROM `products` WHERE `stocks` <= ?");
                    $count_low_stocks->bind_param("s",$stocks);
                    $count_low_stocks->execute();
                    $result_stocks = $count_low_stocks->get_result();
                    if($result_stocks->num_rows>0){
                      while($row_stocks = mysqli_fetch_assoc($result_stocks)){
                          $low_stocks = htmlspecialchars($row_stocks['low_stocks'] ?? 0);
                      }
                    }
                    ?>
                    <h4><?php echo $low_stocks; ?></h4>
                    <p class="mb-0">Low Stock</p>
                  </div>
                  <div class="icon-box lowstock-icon"><i class="bi bi-exclamation-triangle"></i></div>
                </div>
              </div>
            </div>
                </div>
                <div class="col-lg-4">
                  <!-- <h3 class="fw-bold">Top 3 Products</h3> -->
                  <div class="inner-top-products stat-card ">
                          <div class="d-flex flex-column">
                            <h6>TOP 3 PRODUCTS</h6>
                            <?php
                        $number = 1;  
                        $get_top = $conn->query("
                            SELECT product_id, COUNT(*) AS total_count
                            FROM checkout
                            GROUP BY product_id
                            ORDER BY total_count DESC
                            LIMIT 3
                        ");

                        if($get_top->num_rows > 0){

                            while($row = $get_top->fetch_assoc()){

                                $product_id = $row['product_id'];
                                $count = $row['total_count'];

                                // Get product details
                                $get_products = $conn->prepare("SELECT product_name FROM products WHERE product_id = ?");
                                $get_products->bind_param("s", $product_id);
                                $get_products->execute();
                                $result_product = $get_products->get_result();

                                if($result_product->num_rows > 0){
                                    $row_product = $result_product->fetch_assoc();
                                    $product_name = $row_product['product_name'];
                                } else {
                                    $product_name = "Unknown product";
                                }
                                if ($number == 1) {
                                    $icon = 'bi bi-box-seam';    
                                    $bg_color = "bg-warning";
                                } elseif ($number == 2) {
                                    $icon = 'bi bi-cart';    
                                    $bg_color = "bg-primary";
                                } elseif ($number == 3) {
                                     $icon = 'bi bi-basket-fill';    
                                    $bg_color = "bg-danger";
                                } else {
                                    $icon = 'bi-question-circle';
                                }
                                ?>

                                <div class="d-flex align-items-center mb-1">
                                   <div class="<?php echo $bg_color; ?> p-2 me-2 rounded-3"><i class="<?php echo  $icon; ?> text-light"></i></div>
                                  <p>
                                    <?php echo $number . '.' . ' ' . $product_name;?>
                                  </p>
                                </div>
                          
                                      <?php
                            $number++;
                              
                            }

                        } else {
                            echo "No data found.";
                        }


                              

             
                          ?>  
                      </div>
                  </div>
                </div>
                <div class="col-lg-6 mb-3">
               <?php
                      $claimed = 'Claimed';

               
                      $currentYear  = date('Y');
                      $currentMonth = date('m');

                      $query = $conn->prepare("
                          SELECT 
                              DATE_FORMAT(date, '%M') AS month_name,  -- full month name
                              SUM(total) AS total_amount
                          FROM checkout
                          WHERE status = ?
                            AND YEAR(date) = ?
                            AND MONTH(date) = ?
                          GROUP BY YEAR(date), MONTH(date)
                      ");
                      $query->bind_param("sss", $claimed, $currentYear, $currentMonth);
                      $query->execute();
                      $result = $query->get_result();

                      $months = [];
                      $amounts = [];

                      if($result->num_rows > 0){
                          while($row = $result->fetch_assoc()){
                              $months[] = $row['month_name'];       
                              $amounts[] = $row['total_amount'];    
                          }
                      } else {
                    
                          $months[] = date('F'); 
                          $amounts[] = 0;
                      }
                      ?>


                 <div style="width: 250px; height: 250px; margin: auto;">
                  <canvas id="salesPieChart"></canvas>
              </div>
              </div>
              <div class="col-lg-6 mb-3">
              <h3 class="fw-bold">Check Out This Month</h3>
             <?php

              $limit = 3; // 3 rows per page
              $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
              if ($page < 1) $page = 1;

              $offset = ($page - 1) * $limit;

              // --- FILTER FOR THIS MONTH ---
              $current_month = date("m");
              $current_year = date("Y");

              $status = "Claimed";

              // --- GET TOTAL ROWS FOR PAGINATION ---
              $count_stmt = $conn->prepare("
                  SELECT COUNT(*) AS total_rows 
                  FROM checkout 
                  WHERE status = ? 
                    AND MONTH(date) = ? 
                    AND YEAR(date) = ?
              ");
              $count_stmt->bind_param("sii", $status, $current_month, $current_year);
              $count_stmt->execute();
              $count_result = $count_stmt->get_result()->fetch_assoc();

              $total_rows = $count_result['total_rows'];
              $total_pages = ceil($total_rows / $limit);

              // --- GET PAGINATED DATA ---
              $stmt = $conn->prepare("
                  SELECT * FROM checkout 
                  WHERE status = ? 
                    AND MONTH(date) = ? 
                    AND YEAR(date) = ? 
                  ORDER BY date DESC 
                  LIMIT ?, ?
              ");
              $stmt->bind_param("siiii", $status, $current_month, $current_year, $offset, $limit);
              $stmt->execute();
              $result_data = $stmt->get_result();
              ?>

              <div class="overflow-auto">
                  <table class="table">
                      <thead>
                          <tr>
                              <th>Products</th>
                              <th>Total Checkout</th>
                              <th>Date</th>
                          </tr>
                      </thead>
                      <tbody>

                      <?php
                      if ($result_data->num_rows > 0) {
                          while ($row_data = $result_data->fetch_assoc()) {
                              
                              $product_id = $row_data['product_id'];
                              $total = $row_data['total'];
                              $date = $row_data['date'];

                              // GET PRODUCT DETAILS
                              $prod = $conn->prepare("SELECT product_name FROM products WHERE product_id = ?");
                              $prod->bind_param("s", $product_id);
                              $prod->execute();
                              $product_res = $prod->get_result()->fetch_assoc();

                              $product_name = $product_res['product_name'];
                      ?>
                          <tr>
                              <td><?php echo htmlspecialchars($product_name); ?></td>
                              <td>₱<?php 
                            $clean_total = floatval(str_replace(',', '', $total));
                            echo number_format($clean_total, 2);
                            ?>
                            </td>
                              <td><?php echo htmlspecialchars($date); ?></td>
                          </tr>
                      <?php
                          }
                      } else {
                          echo "<tr><td colspan='3' class='text-center'>No data this month</td></tr>";
                      }
                      ?>
                      </tbody>
                  </table>
              </div>

              <!-- PAGINATION -->
              <nav aria-label="Page navigation example">
                <ul class="pagination">

                  <!-- Previous Button -->
                  <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                  </li>

                  <!-- Page Numbers -->
                  <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                    <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                      <a class="page-link" href="?page=<?php echo $i; ?>">
                        <?php echo $i; ?>
                      </a>
                    </li>
                  <?php } ?>

                  <!-- Next Button -->
                  <li class="page-item <?php if ($page >= $total_pages) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                  </li>

                </ul>
              </nav>

              </div>
            </div>


      <div class="row">
        <!-- Recent Orders -->
        <div class="col-md-12">
          
        </div>
        <div class="col-lg-12">
          <?php include 'report.php'; ?>
        </div>
      </div>
      

    </main>
  </div>
</div>


<?php     include '../alerts.php'; ?>
<script src="../js/scripts.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_orders.php", 
        method: "GET",
        success: function(response) {
            $('.orders').html(response);
        },
        error: function() {
            $('.orders').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>


<script>
const months = <?php echo json_encode($months); ?>;
const amounts = <?php echo json_encode($amounts); ?>;

const ctx = document.getElementById('salesPieChart').getContext('2d');

new Chart(ctx, {
    type: 'pie',
    data: {
        labels: months,
        datasets: [{
            data: amounts,
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'bottom' },
            title: {
                display: true,
                text: 'Monthly Claimed Checkout Sales'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        let value = context.raw;
                        // Add Peso + comma formatting
                        let formatted = "₱" + value.toLocaleString();
                        return context.label + ": " + formatted;
                    }
                }
            }
        }
    }
});
</script>
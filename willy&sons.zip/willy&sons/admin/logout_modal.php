<!-- Logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-light">
        <h5 class="modal-title"> Logout Confirmation</h5>
      </div>
      <div class="modal-body text-center">
        Are you sure you want to logout?
      </div>
      <div class="modal-footer d-flex flex-column bg-danger text-light">
       <div class="d-flex gap-2 w-100">
         <button type="button" class="btn border text-light bg-danger w-100" data-bs-dismiss="modal">Cancel</button>
          <a href="logout.php" class="btn btn-danger w-100 border ">Logout</a>
       </div>
      </div>
    </div>
  </div>
</div>
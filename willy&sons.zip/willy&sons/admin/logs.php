<?php include 'inventory.php' ?>



<main>
    <section class="add-bestseller-section">
        <form action="function.php" method="POST">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <h3 class="fw-bold">Logs</h3>
                    <button type="button" onclick="location.href='inventory.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="overflow-auto">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Action</th>
                                <th>Date</th>
                                <th>Type</th>
                            </tr>
                            <tbody>
                                <?php
                                $number = 1;
                                $get_logs =  $conn->prepare("SELECT * FROM `logs` ORDER BY `date` DESC");
                                $get_logs->execute();
                                $result_logs = $get_logs->get_result();
                                if($result_logs->num_rows>0){
                                    while($row_logs = mysqli_fetch_assoc($result_logs)){
                                        $action = htmlspecialchars($row_logs['action']);
                                        $date = htmlspecialchars($row_logs['date']);
                                        $type = htmlspecialchars($row_logs['type']);
                                        ?>
                                        <tr>
                                            <td><?php echo $number; ?></td>
                                            <td><?php echo $action; ?></td>
                                            <td><?php echo $date; ?></td>
                                            <td><?php echo $type; ?></td>
                                        </tr>
                                        <?php
                                        $number++;
                                    }
                                }else{
                                    echo "<tr><td colspan='4'>No Logs Found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </thead>
                    </table>
                  </div>
                </div>
                <div class="modal-footer border-0">
                  
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Dashboard</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../js/splide.js"></script>
    <script src="../js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
  <?php

    include '../config.php';
    include 'logout_modal.php';
     if(!isset($_SESSION['active_login'])){
  echo "<script>location.href='../index.php';</script>";
  exit;
}
$status = 'Unclaimed';
$update = $conn->prepare("UPDATE `checkout` SET `status` = ? WHERE `expiration_date` > ? AND `expiration_time` > ?");
$update->bind_param("sss",$status, $datetoday,$timetoday);
$update->execute();
  ?>
  <style>
  body {
    background: #f8f9fa;
    font-family: 'Segoe UI', sans-serif;
  }

  .sidebar {
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 250px;/* adjust width as needed */
  background: #c72429;
  color: #fff;
  padding-top: 20px;
  margin: 0; /* remove extra space */
  z-index: 1030; /* para laging nasa ibabaw */
}

  .sidebar .nav-link {
    color: #f1f1f1;
    font-weight: 500;
    border-radius: 6px;
    margin: 3px 8px;
    transition: all 0.2s;
  }

  .sidebar .nav-link i {
    color: #f8d7d7;
    transition: all 0.2s;
  }

  .sidebar .nav-link:hover {
    background: rgba(255, 255, 255, 0.2);
    color: #fff;
  }

  .sidebar .nav-link:hover i {
    color: #fff;
  }

  .active {
    background: #fff;
    color: #ff3300 !important;
    font-weight: 600;
  }

  .sidebar .nav-link.active i {
    color: #ff3300 !important;
  }

  .navbar {
    background: #fff;
    border-bottom: 1px solid #dee2e6;
  }

  .card {
    border-radius: 15px;
    border: none;
    box-shadow: 0 3px 6px rgba(0,0,0,0.05);
  }

  .btn-action {
    padding: 4px 8px;
    border-radius: 6px;
  }

  /* Order status styles */
  .status-badge {
    font-size: 0.8rem;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
  }
  .pending { background: #fff3cd; color: #856404; }
  .processing { background: #cce5ff; color: #004085; }
  .completed { background: #d4edda; color: #155724; }
  .cancelled { background: #f8d7da; color: #721c24; }
</style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar (desktop only) -->
    <nav class="col-md-2 d-none d-md-block sidebar">
      <div class="text-center mb-4">
        <div class="d-flex align-items-center justify-content-center">
              <img src="../image/logo.png" alt="Logo" width="40" height="40" class="me-2">
              <h5 class="fw-bold mb-0">Willy & Sons</h5>
            </div>
            </div>
            <div class="nav flex-column">
              <a class="nav-link  d-flex align-items-center py-2" href="index.php">
                <i class="bi bi-speedometer2 fs-5 me-2"></i> <span>Dashboard</span>
              </a>
              <a class="nav-link active d-flex align-items-center py-2" href="orders.php">
               <i class="bi bi-bag-check fs-5 me-2"></i> <span>Orders <div id="orders" class="position-relative"></div></span>
              </a>
              <a class="nav-link d-flex align-items-center py-2" href="inventory.php">
                <i class="bi bi-box-seam fs-5 me-2"></i> <span>Inventory</span>
              </a>
              <!--<a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
              <a class="nav-link d-flex align-items-center py-2" href="customers.php">
                <i class="bi bi-people fs-5 me-2"></i> <span>Customers</span>
              </a>
               <a class="nav-link d-flex align-items-center py-2" href="archive.php">
                <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
              </a>
              <a class="nav-link d-flex align-items-center py-2 " href=""  data-bs-toggle="modal" data-bs-target="#logoutModal">
                <i class="bi bi-box-arrow-left fs-5 me-2"></i>  <span>Logout</span>
              </a>
            </div>
    </nav>

    <!-- Offcanvas mobile -->
     <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar">
      <div class="offcanvas-header">
        <h5 class="fw-bold text-danger">Willy & Sons</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div class="offcanvas-body">
        <div class="nav flex-column">
          <a class="nav-link " href="index.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
          <a class="nav-link active" href="orders.php"><i class="bi bi-bag-check me-2"></i> Orders</a>
          <a class="nav-link" href="inventory.php"><i class="bi bi-box-seam me-2"></i> Inventory</a>
         <!-- <a class="nav-link" href="report.php"><i class="bi bi-bar-chart-line-fill me-2"></i> Reports</a>-->
          <a class="nav-link" href="customers.php"><i class="bi bi-people me-2"></i> Customers</a>
          <a class="nav-link d-flex align-items-center py-2" href="archive.php">
            <i class="bi bi-archive"></i> <span>&nbsp;&nbsp;Archive</span>
          </a>
          <a class="nav-link" href="" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-left fs-5 me-2"></i>  Logout</a>
        </div>
      </div>
    </div>


    <!-- Main Content -->
    <main class="col-md-10 ms-sm-auto px-md-4">
      <!-- Navbar -->
      <nav class="navbar px-3">
        <button class="btn d-md-none" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar">
          <i class="bi bi-list fs-3"></i>
        </button>
        <div class="d-flex align-items-center w-100 justify-content-between">
          <span class="fw-semibold">Order Management</span>
          <form class="d-none d-md-flex" method="GET">
            <input type="text" name="search_input" class="form-control form-control-sm me-2" placeholder="Search checkout ID...">
            <button type="submit" name="search_button" class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button>
          </form>
        </div>
      </nav>

      <!-- Orders Table -->
      <div class="card p-3 mt-3">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="mb-0">Orders List</h5>
        </div>

        <div class="table-responsive">
          <table class="table align-middle">
            <thead class="table-light">
              <tr>
                <th>Checkout ID</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Time</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if(isset($_GET['search_button'])){
                $search_input = $_GET['search_input'] ?? '';

                if(!empty($search_input)){
                   $get_checkout = $conn->prepare("SELECT * FROM `checkout`  WHERE `checkout_id` = ? ");
                   $get_checkout->bind_param("s",$search_input);
                }else{
                   $get_checkout = $conn->prepare("SELECT * FROM `checkout`  ");
                }
             
              $get_checkout->execute();
              $result_checkout = $get_checkout->get_result();
              if($result_checkout->num_rows>0){
                while($row_checkout = mysqli_fetch_assoc($result_checkout)){
                  $checkout_id  = htmlspecialchars($row_checkout['checkout_id']);
                  $user_id  = htmlspecialchars($row_checkout['user_id']);
                  $product_id  = htmlspecialchars($row_checkout['product_id']);
                  $date  = htmlspecialchars($row_checkout['date']);
                  $time  = htmlspecialchars($row_checkout['time']);
                  $quantity  = htmlspecialchars($row_checkout['quantity']);
                  $total  = htmlspecialchars($row_checkout['total']);
                  $status  = htmlspecialchars($row_checkout['status']);
             
                $get_accounts = $conn->prepare("SELECT * FROM `accounts` WHERE `user_id` = ?");
                $get_accounts->bind_param("s",$user_id);
                $get_accounts->execute();
                $result_account = $get_accounts->get_result();
                if($result_account->num_rows>0){
                  while($row_account = mysqli_fetch_assoc($result_account)){
                    $fullname = htmlspecialchars($row_account['firstname']) . ' ' . htmlspecialchars($row_account['lastname']) ;
                
                    if($status === 'Pending'){
                      $style = "bg-warning text-dark fw-bold";
                    }elseif($status === 'Approved'){
                       $style = "bg-success text-light fw-bold";
                    }else{
                       $style = "bg-danger text-light fw-bold";
                    }
              ?>
              <tr>
                <td><?php echo $checkout_id; ?></td>
                <td><?php echo $fullname; ?></td>
                <td><?php echo $date; ?></td>
                 <td><?php echo $time; ?></td>
                <td>₱<?php echo $total; ?></td>
                <td><span class="<?php echo $style; ?> p-1 rounded-3"><?php echo $status; ?></span></td>
                <td>
                  <button onclick="location.href='view_order.php?checkout_id=<?php echo $checkout_id; ?>'" class="btn btn-sm btn-outline-primary btn-action" data-bs-toggle="tooltip" title="View">
                    <i class="bi bi-eye"></i>
                  </button>

                </td>
              </tr>
                <?php
                  }
                }else{
                        echo "<tr><td colspamn='7'>User not Found</td></tr>";
                }
                 }
              }else{
                echo "<tr><td colspamn='7'>No Ordered Found</td></tr>";
              }

                   
              }else{
                     $get_checkout = $conn->prepare("SELECT * FROM `checkout`  ");
              $get_checkout->execute();
              $result_checkout = $get_checkout->get_result();
              if($result_checkout->num_rows>0){
                while($row_checkout = mysqli_fetch_assoc($result_checkout)){
                  $checkout_id  = htmlspecialchars($row_checkout['checkout_id']);
                  $user_id  = htmlspecialchars($row_checkout['user_id']);
                  $product_id  = htmlspecialchars($row_checkout['product_id']);
                  $date  = htmlspecialchars($row_checkout['date']);
                  $time  = htmlspecialchars($row_checkout['time']);
                  $quantity  = htmlspecialchars($row_checkout['quantity']);
                  $total  = htmlspecialchars($row_checkout['total']);
                  $status  = htmlspecialchars($row_checkout['status']);
             
                $get_accounts = $conn->prepare("SELECT * FROM `accounts` WHERE `user_id` = ?");
                $get_accounts->bind_param("s",$user_id);
                $get_accounts->execute();
                $result_account = $get_accounts->get_result();
                if($result_account->num_rows>0){
                  while($row_account = mysqli_fetch_assoc($result_account)){
                    $fullname = htmlspecialchars($row_account['firstname']) . ' ' . htmlspecialchars($row_account['lastname']) ;
                
                    if($status === 'Pending'){
                      $style = "bg-warning text-dark fw-bold";
                    }elseif($status === 'Approved'){
                       $style = "bg-success text-light fw-bold";
                    }else{
                       $style = "bg-danger text-light fw-bold";
                    }
              ?>
              <tr>
                <td><?php echo $checkout_id; ?></td>
                <td><?php echo $fullname; ?></td>
                <td><?php echo $date; ?></td>
                 <td><?php echo $time; ?></td>
                <td>₱<?php echo $total; ?></td>
                <td><span class="<?php echo $style; ?> p-1 rounded-3"><?php echo $status; ?></span></td>
                <td>
                  <button onclick="location.href='view_order.php?checkout_id=<?php echo $checkout_id; ?>'" class="btn btn-sm btn-outline-primary btn-action" data-bs-toggle="tooltip" title="View">
                    <i class="bi bi-eye"></i>
                  </button>

                </td>
              </tr>
                <?php
                  }
                }else{
                        echo "<tr><td colspamn='7'>User not Found</td></tr>";
                }
                 }
              }else{
                echo "<tr><td colspamn='7'>No Ordered Found</td></tr>";
              }

              }
                ?>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>

<?php     include '../alerts.php'; ?>
<script src="../js/scripts.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_orders.php", 
        method: "GET",
        success: function(response) {
            $('#orders').html(response);
        },
        error: function() {
            $('#orders').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Inventory</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>


    .card {
      border-radius: 12px;
      border: none;
      box-shadow: 0 4px 14px rgba(0,0,0,0.04);
    }

    .chart-card {
      min-height: 260px;
    }

    @media (max-width: 767.98px) {
      .sidebar { display: none; }
      .navbar { margin-left: 0; }
      main { margin-left: 0; }
    }
  </style>
</head>
<body>


<!-- Main content -->
<main>
  <!-- Summary cards -->
  <div class="row g-3 mb-3">

  <!-- Recent Orders -->
  <div class="col-lg-6">
    <div class="card p-3 h-100">
      <div class="d-flex justify-content-between align-items-center">
        <h6 class="fw-bold">Recent Orders</h6>
      </div>

      <ul class="list-group list-group-flush mt-2">
        <?php
        $limit = 3;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $limit;

        $count_query = $conn->prepare("SELECT COUNT(*) AS total FROM `checkout` WHERE `date` = ?");
        $count_query->bind_param("s", $datetoday);
        $count_query->execute();
        $count_result = $count_query->get_result();
        $total_rows = $count_result->fetch_assoc()['total'] ?? 0;
        $total_pages = ceil($total_rows / $limit);

        // 🛒 Fetch paginated orders
        $get_orders = $conn->prepare("SELECT * FROM `checkout` WHERE `date` = ? ORDER BY `time` DESC LIMIT ?, ?");
        $get_orders->bind_param("sii", $datetoday, $offset, $limit);
        $get_orders->execute();
        $result_order_today = $get_orders->get_result();

        if ($result_order_today->num_rows > 0) {
          while ($row_order = mysqli_fetch_assoc($result_order_today)) {
            $checkout_id = htmlspecialchars($row_order['checkout_id']);
            $user_id     = htmlspecialchars($row_order['user_id']);
            $product_id  = htmlspecialchars($row_order['product_id']);
            $date        = htmlspecialchars($row_order['date']);
            $time        = htmlspecialchars($row_order['time']);
            $quantity    = htmlspecialchars($row_order['quantity']);
            $total       = htmlspecialchars($row_order['total']);
            $status      = htmlspecialchars($row_order['status']);

            // Get user info
            $get_user = $conn->prepare("SELECT * FROM `accounts` WHERE `user_id` = ?");
            $get_user->bind_param("s", $user_id);
            $get_user->execute();
            $result_user = $get_user->get_result();

            if ($result_user->num_rows > 0) {
              $row_user = mysqli_fetch_assoc($result_user);
              $fullname = htmlspecialchars($row_user['lastname']) . ' ' . htmlspecialchars($row_user['firstname']);

              // Get product info
              $products = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
              $products->bind_param("s", $product_id);
              $products->execute();
              $result_products = $products->get_result();

              if ($result_products->num_rows > 0) {
                $row_products = mysqli_fetch_assoc($result_products);
                $product_name = htmlspecialchars($row_products['product_name']);
        ?>
                <li class="list-group-item d-flex justify-content-between">
                  <div>
                    <strong><?php echo $checkout_id; ?></strong><br>
                    <?php echo $fullname; ?><br>
                    <small><?php echo $product_name; ?></small>
                  </div>
                  <div class="text-end">
                    <span class="status-badge completed"><?php echo $status; ?></span><br>
                    <strong>₱<?php echo $total; ?></strong><br>
                    <small><?php echo $date; ?></small>
                  </div>
                </li>
        <?php
              }
            }
          }
        } else {
          echo "<li class='list-group-item text-center'>No Recent Orders</li>";
        }
        ?>
      </ul>

      <!-- PAGINATION -->
      <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation example" class="mt-3">
          <ul class="pagination justify-content-center mb-0">
            <!-- Previous -->
            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
              <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
            </li>

            <!-- Page Numbers -->
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
              <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
              </li>
            <?php endfor; ?>

            <!-- Next -->
            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
              <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
            </li>
          </ul>
        </nav>
      <?php endif; ?>
    </div>
  </div>

  <!-- Summary Cards (Right Column) -->
  <div class="col-lg-6">
    <div class="row g-3">

      <!-- Total Sales -->
      <div class="col-md-4">
        <div class="card p-3 h-100">
          <small class="text-muted">Total Sales</small>
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <?php
              $status_sales = 'Claimed';
              $sales = $conn->prepare("SELECT SUM(total) as total_sales FROM `checkout` WHERE `status` = ?");
              $sales->bind_param("s", $status_sales);
              $sales->execute();
              $result_sales = $sales->get_result();
              $total_sales = 0;
              if ($result_sales->num_rows > 0) {
                $row_sales = mysqli_fetch_assoc($result_sales);
                $total_sales = htmlspecialchars($row_sales['total_sales'] ?? 0);
              }
              ?>
              <h3 class="h3 mb-0">₱<?php echo number_format($total_sales, 2); ?></h3>
            </div>
            <i class="bi bi-cash fs-2 text-warning"></i>
          </div>
        </div>
      </div>

      <!-- Total Orders -->
      <div class="col-md-4">
        <div class="card p-3 h-100">
          <small class="text-muted">Total Orders</small>
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <?php
              $status_sales = 'Claimed';
              $sales = $conn->prepare("SELECT COUNT(*) as total_orders FROM `checkout` WHERE `status` = ?");
              $sales->bind_param("s", $status_sales);
              $sales->execute();
              $result_sales = $sales->get_result();
              $total_orders = 0;
              if ($result_sales->num_rows > 0) {
                $row_sales = mysqli_fetch_assoc($result_sales);
                $total_orders = htmlspecialchars($row_sales['total_orders'] ?? 0);
              }
              ?>
              <h3 class="h3 mb-0"><?php echo $total_orders; ?></h3>
            </div>
            <i class="bi bi-bag-check fs-2 text-primary"></i>
          </div>
        </div>
      </div>

      <!-- Low Stock Items -->
      <div class="col-md-4">
        <div class="card p-3 h-100">
          <small class="text-muted">Low Stock Items</small>
          <div class="d-flex align-items-center justify-content-between">
            <div>
              <?php
              $limit_stock = 5;
              $sales = $conn->prepare("SELECT COUNT(*) AS low_stocks FROM `products` WHERE `stocks` <= ?");
              $sales->bind_param("i", $limit_stock);
              $sales->execute();
              $result_sales = $sales->get_result();
              $low_stocks = 0;
              if ($result_sales->num_rows > 0) {
                $row_sales = $result_sales->fetch_assoc();
                $low_stocks = htmlspecialchars($row_sales['low_stocks'] ?? 0);
              }
              ?>
              <h3 class="h3 mb-0"><?php echo $low_stocks; ?></h3>
            </div>
            <i class="bi bi-exclamation-triangle fs-2 text-danger"></i>
          </div>
        </div>
      </div>

    </div>
  </div>

</div>

<?php
$claimed = 'Claimed';
$data = array_fill(1, 12, 0); // default 0 for all 12 months

$get_sales = $conn->prepare("
    SELECT MONTH(`date`) AS month, SUM(`total`) AS total_sales 
    FROM `checkout`
    WHERE `status` = ?
    GROUP BY MONTH(`date`)
");
$get_sales->bind_param("s", $claimed);
$get_sales->execute();
$result_sales = $get_sales->get_result();

if ($result_sales->num_rows > 0) {
    while ($row = $result_sales->fetch_assoc()) {
        $month = (int)$row['month'];
        $data[$month] = (float)$row['total_sales'];
    }
}

// Convert PHP array to JavaScript array
$monthly_sales = json_encode(array_values($data));
?>

<?php
$claimed = 'Claimed';
$get_trand_products = $conn->prepare("SELECT * FROM `checkout` WHERE `status` = ?");
$get_trand_products->bind_param("s",$claimed);
$get_trand_products->execute();
$result_trends = $get_trand_products->get_result();
if($result_trends->num_rows>0){
  while($row_trends = mysqli_fetch_assoc($result_trends)){
    $product_id = htmlspecialchars($row_trends['product_id']);


$get_product = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
$get_product->bind_param("s",$product_id);
$get_product->execute();
$result_pro = $get_product->get_result();
if($result_pro->num_rows>0){
  while($pro = mysqli_fetch_assoc($result_pro)){
    $product_name = htmlspecialchars($pro['product_name']);
  }
}
  }
}
?>

<?php
$claimed = 'Claimed';

// Query: sum total sales per product
$get_trends = $conn->prepare("
  SELECT p.product_name, SUM(c.total) AS total_sales
  FROM checkout c
  JOIN products p ON c.product_id = p.product_id
  WHERE c.status = ?
  GROUP BY c.product_id
  ORDER BY total_sales DESC
  LIMIT 5
");
$get_trends->bind_param("s", $claimed);
$get_trends->execute();
$result_trends = $get_trends->get_result();

$product_names = [];
$sales_values = [];

if ($result_trends->num_rows > 0) {
  while ($row = $result_trends->fetch_assoc()) {
    $product_names[] = htmlspecialchars($row['product_name']);
    $sales_values[] = (float)$row['total_sales'];
  }
}

// Convert to JS-friendly format
$js_product_names = json_encode($product_names);
$js_sales_values = json_encode($sales_values);
?>


  <!-- Charts row -->
<div class="row g-3 mb-3">
  <div class="col-lg-12">
    <div class="card p-3 chart-card">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="mb-0 fw-semibold">Sales (Last 12 months)</h6>
        <div class="small text-muted">Currency: PHP</div>
      </div>

    <div class="overflow-auto">
      <table class="table">
        <thead>
          <tr>
            <th>Checkout ID</th>
            <th>Date</th>
            <th>Time</th>
            <th>Product ID</th>
            <th>Quantity</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody id="checkoutTable">
          <?php
            $status = 'Claimed';
            $get_data = $conn->prepare("SELECT * FROM `checkout` WHERE `status` = ? ORDER BY `date` DESC");
            $get_data->bind_param("s", $status);
            $get_data->execute();
            $result_data = $get_data->get_result();

            $row_count = 0;
            if($result_data->num_rows > 0){
              while($row_data = mysqli_fetch_assoc($result_data)){
                $row_count++;
                $checkout_id = htmlspecialchars($row_data['checkout_id']);
                $date = htmlspecialchars($row_data['date']);
                $time = htmlspecialchars($row_data['time']);
                $product_id = htmlspecialchars($row_data['product_id']);
                $quantity = htmlspecialchars($row_data['quantity']);
                $total = htmlspecialchars($row_data['total']);
                ?>
                <tr class="checkout-row <?php echo ($row_count > 5) ? 'd-none extra-row' : ''; ?>">
                  <td><?php echo $checkout_id; ?></td>
                  <td><?php echo $date; ?></td>
                  <td><?php echo $time; ?></td>
                  <td><?php echo $product_id; ?></td>
                  <td><?php echo $quantity; ?></td>
                  <td>₱<?php echo $total; ?></td>
                </tr>
                <?php
              }
            }
          ?>
        </tbody>
      </table>
    </div>
  <?php if($row_count > 5): ?>
    <div class="text-center mt-3">
      <button id="viewMoreBtn" class="btn btn-sm btn-outline-primary">View More</button>
    </div>
  <?php endif; ?>
</div>
      
      <!-- 📥 Download Button -->
      <div class="mt-3 text-end">
        <button id="downloadSalesChart" onclick="location.href='download.php'" class="btn btn-sm btn-outline-danger">
          <i class="bi bi-download"></i> Download Table
        </button>
      </div>
    </div>
  </div>
<!--
  <div class="col-lg-12">
    <div class="card p-3 chart-card">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="mb-0 fw-semibold">Top Products</h6>
        <small class="text-muted">By Revenue</small>
      </div>
      <canvas id="topProductsChart" style="max-height:320px;"></canvas>
    </div>
  </div>-->
</div>


</main>

<?php
  $claimed = 'Claimed';
  $get_sales = $conn->prepare("SELECT * FROM `checkout` WHERE `status` = ?");
  $get_sales->bind_param("s",$claimed);
  $get_sales->execute();
  $result_sales = $get_sales->get_result();
  if($result_sales->num_rows>0){
    while($row_sales = mysqli_fetch_assoc($result_sales)){
      $date = htmlspecialchars($row_sales['date'] ?? '');
      $total = htmlspecialchars($row_sales['total'] ?? '');

    }
  }
?>
<script>
  /*
const salesCtx = document.getElementById('salesChart');
const monthlySales = <?php echo $monthly_sales; ?>;

const salesChart = new Chart(salesCtx, {
  type: 'line',
  data: {
    labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    datasets: [{
      label: 'Sales (PHP)',
      data: monthlySales,
      fill: true,
      borderColor: '#dc3545',
      backgroundColor: 'rgba(220,53,69,0.1)',
      tension: 0.3,
      borderWidth: 2,
      pointRadius: 4,
      pointBackgroundColor: '#dc3545'
    }]
  },
  options: {
    plugins: { legend: { display: false } },
    maintainAspectRatio: false,
    scales: {
      y: { beginAtZero: true },
      x: { grid: { display: false } }
    }
  }
});

const topCtx = document.getElementById('topProductsChart');
const productNames = <?php echo $js_product_names; ?>;
const salesValues = <?php echo $js_sales_values; ?>;

const topProductsChart = new Chart(topCtx, {
  type: 'doughnut',
  data: {
    labels: productNames,
    datasets: [{
      data: salesValues,
      backgroundColor: [
        '#dc3545', '#fd7e14', '#ffc107', '#198754', '#0d6efd'
      ],
      borderWidth: 1,
      hoverOffset: 8
    }]
  },
  options: {
    plugins: { 
      legend: { position: 'bottom' },
      tooltip: {
        callbacks: {
          label: (context) => {
            return context.label + ': ₱' + context.parsed.toLocaleString();
          }
        }
      }
    },
    maintainAspectRatio: false
  }
});

// 📥 Download Line Graph
document.getElementById('downloadSalesChart').addEventListener('click', function() {
  const link = document.createElement('a');
  link.download = 'sales_chart.png';
  link.href = salesChart.toBase64Image();
  link.click();
});*/
</script>

<?php     include '../alerts.php'; ?>
<script src="../js/scripts.js"></script>
<script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>

  <script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "fetch_orders.php", 
        method: "GET",
        success: function(response) {
            $('.orders').html(response);
        },
        error: function() {
            $('.orders').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>



<script>
document.getElementById("viewMoreBtn")?.addEventListener("click", function() {
  document.querySelectorAll(".extra-row").forEach(row => row.classList.remove("d-none"));
  this.style.display = "none"; // Hide button after clicking
});
</script>
<?php include 'inventory.php' ?>



<main>
    <section class="add-bestseller-section">
        <form action="function.php" method="POST">
            <!-- Modal -->
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header border-0">
                    <h3 class="fw-bold">Stock Out</h3>
                    <button type="button" onclick="location.href='inventory.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="main-content">
                    <div class="mb-3">
                        <label for="">Select Product</label>
                        <select name="product_id" class="form-control" id="" required>
                            <?php
                             $get_products= $conn->prepare("SELECT * FROM `products`");
                             $get_products->execute();
                             $result_products = $get_products->get_result();
                             if($result_products->num_rows>0){
                                while($row_stocks = mysqli_fetch_assoc($result_products)){
                                    $product_name = htmlspecialchars($row_stocks['product_name']);
                                    $product_id  = htmlspecialchars($row_stocks['product_id']);
                                    $brand_name  = htmlspecialchars($row_stocks['brand_name']);
                                    ?>
                                    <option value="<?php echo $product_id; ?>">(<?php echo $brand_name; ?>)-<?php echo $product_name; ?></option>
                                    <?php
                                }
                             }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Stocks</label>
                        <input type="text" class="form-control" name="stocks" required>
                    </div>
                  </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="stock_out" class="btn btn-primary">Update</button>
                </div>
                </div>
            </div>
            </div>
        </form>
    </section>
</main>
<?php
include 'inventory.php'; 

$status = 'Active';
$stock = 5;

// Get all products with low stock
$get_low_stocks = $conn->prepare("
    SELECT product_id, product_name, brand_name, category, stocks
    FROM products 
    WHERE status = ? AND stocks <= ?
");
$get_low_stocks->bind_param("si", $status, $stock);
$get_low_stocks->execute();
$result_stocks = $get_low_stocks->get_result();
$total_stocks = $result_stocks->num_rows;
?>

<style>
    .modal-content {
  border-radius: 15px;
  overflow: hidden;
}

.table thead th {
  font-weight: 600;
  background-color: #5c0201 !important;
  color: white !important;
}

.badge.bg-warning {
  background-color: #ffc107 !important;
}

.badge.bg-danger {
  background-color: #5c0201 !important;
}

</style>

<main>
  <section class="delete-category-section">
    <form action="function.php" method="POST">
      <!-- 🛎️ Modal -->
      <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
          <div class="modal-content shadow-lg border-0">
            
            <!-- Header -->
            <div class="modal-header bg-danger text-white d-flex align-items-center">
              <img src="../image/bell.png" alt="Alert" width="28" height="28" class="me-2">
              <h5 class="modal-title mb-0 fw-semibold">
                Stock Alerts 
                <span class="badge bg-light text-danger ms-1"><?php echo $total_stocks; ?></span>
              </h5>
              <button type="button" onclick="location.href='inventory.php'" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <!-- Body -->
            <div class="modal-body">
              <?php if ($total_stocks > 0): ?>
                <div class="table-responsive">
                  <table class="table align-middle table-striped">
                    <thead class="table-danger text-center">
                      <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Brand</th>
                        <th>Category</th>
                        <th>Stocks</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody class="text-center">
                      <?php
                        $count = 1;
                        while($row = mysqli_fetch_assoc($result_stocks)):
                          $product_name = htmlspecialchars($row['product_name']);
                          $brand_name = htmlspecialchars($row['brand_name']);
                          $category = htmlspecialchars($row['category']);
                          $stocks = (int)$row['stocks'];

                          $get_category = $conn->prepare("SELECT * FROM `categories` WHERE `category_id` = ?");
                          $get_category->bind_param("s",$category);
                          $get_category->execute();
                          $result_Cat = $get_category->get_result();
                          if($result_Cat->num_rows>0){
                            while($row_c = mysqli_fetch_assoc($result_Cat)){
                            $category_name = htmlspecialchars($row_c['category_name'] ?? '');
                           
                      ?>
                      <tr>
                        <td><?php echo $count++; ?></td>
                        <td><?php echo $product_name; ?></td>
                        <td><?php echo $brand_name; ?></td>
                        <td><?php echo $category_name; ?></td>
                        <td>
                          <span class="badge bg-warning text-dark px-3 py-2">
                            <?php echo $stocks ?? 0; ?> left
                          </span>
                        </td>
                        <td>
                          <span class="badge bg-danger">Low Stock</span>
                        </td>
                      </tr>
                      <?php
                       }
                          }
                     endwhile; ?>
                    </tbody>
                  </table>
                </div>
              <?php else: ?>
                <div class="text-center text-muted py-4">
                  <i class="bi bi-check-circle-fill text-success fs-2 mb-2"></i>
                  <p class="fw-semibold mb-0">All stocks are sufficient</p>
                </div>
              <?php endif; ?>
            </div>

            <!-- Footer 
            <div class="modal-footer border-0 justify-content-end">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <a href="inventory.php" class="btn btn-danger">Go to Inventory</a>
            </div>-->

          </div>
        </div>
      </div>
    </form>
  </section>
</main>


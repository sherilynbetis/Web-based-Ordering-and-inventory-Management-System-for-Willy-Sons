<?php
include 'orders.php';
if (isset($_GET['checkout_id'])) {
    $checkout_id = $_GET['checkout_id'] ?? '';
}

$get_orders = $conn->prepare("SELECT * FROM `checkout` WHERE `checkout_id` = ?");
$get_orders->bind_param("s", $checkout_id);
$get_orders->execute();
$result_orders = $get_orders->get_result();
if ($result_orders->num_rows > 0) {
    while ($row_order = mysqli_fetch_assoc($result_orders)) {
        $user_id = htmlspecialchars($row_order['user_id'] ?? '');
        $product_id = htmlspecialchars($row_order['product_id'] ?? '');
        $date = htmlspecialchars($row_order['date'] ?? '');
        $time = htmlspecialchars($row_order['time'] ?? '');
        $quantity = htmlspecialchars($row_order['quantity'] ?? '');
        $total = htmlspecialchars($row_order['total'] ?? '');
        $status = htmlspecialchars($row_order['status'] ?? '');
    }
}

$hide = ($status === 'Pending') ? '' : 'd-none';
$hide_status = ($status === 'Approved') ? '' : 'd-none';

$profile = "";
$get_user = $conn->prepare("SELECT * FROM `accounts` WHERE `user_id` = ?");
$get_user->bind_param("s", $user_id);
$get_user->execute();
$result_user = $get_user->get_result();
if ($result_user->num_rows > 0) {
    while ($row_user = mysqli_fetch_assoc($result_user)) {
        $lastname = htmlspecialchars($row_user['lastname'] ?? '');
        $firstname = htmlspecialchars($row_user['firstname'] ?? '');
        $phone_number = htmlspecialchars($row_user['phone_number'] ?? '');
        $email = htmlspecialchars($row_user['email'] ?? '');
        $profile = htmlspecialchars($row_user['profile'] ?? '');
        $address = htmlspecialchars($row_user['address'] ?? '');
        $street = htmlspecialchars($row_user['street'] ?? '');
        $purok = htmlspecialchars($row_user['purok'] ?? '');
    }
}

$get_product = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
$get_product->bind_param("s", $product_id);
$get_product->execute();
$result_products = $get_product->get_result();
if ($result_products->num_rows > 0) {
    while ($row_products = mysqli_fetch_assoc($result_products)) {
        $product_name = htmlspecialchars($row_products['product_name'] ?? '');
        $brand_name = htmlspecialchars($row_products['brand_name'] ?? '');
        $category_name = htmlspecialchars($row_products['category'] ?? '');
        $status = htmlspecialchars($row_products['status'] ?? '');
        $price = htmlspecialchars($row_products['price'] ?? '');
        $stocks = htmlspecialchars($row_products['stocks'] ?? '');
    }
}

$profile_path = ($profile === "") ? '../image/profile-icon.png' : "../uploads/$profile";
?>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Splide CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/css/splide.min.css">

<style>
    body {
        font-family: 'Poppins', sans-serif;
    }

    .modal-content {
        border-radius: 1rem;
        box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    }

    .modal-header {
        background: #dc3545;
        color: white;
        border-top-left-radius: 1rem;
        border-top-right-radius: 1rem;
        text-align: center;
    }

    .modal-title {
        font-weight: 700;
        letter-spacing: 0.5px;
    }

    .nav-tabs .nav-link.active {
        background-color: #dc3545;
        color: #fff !important;
        border-color: #dc3545;
    }

    .nav-tabs .nav-link {
        color: #dc3545;
        font-weight: 600;
    }

    .profile_path {
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid #dc3545;
        box-shadow: 0 3px 8px rgba(0,0,0,0.15);
    }

    .splide__slide img {
        border-radius: 12px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .details h2 {
        font-size: 1.3rem;
        font-weight: 700;
    }

    .btn {
        border-radius: 8px;
        font-weight: 600;
        padding: 0.5rem 1.25rem;
    }

    .btn-success {
        background-color: #198754;
        border: none;
    }

    .btn-danger {
        background-color: #dc3545;
        border: none;
    }

    .btn-outline-secondary {
        border-color: #dc3545;
        color: #dc3545;
    }

    .btn-outline-secondary:hover {
        background: #dc3545;
        color: white;
    }

    .order-info-card {
        background: #fff5f5;
        border-left: 4px solid #dc3545;
        padding: 1rem 1.25rem;
        border-radius: 8px;
    }

    .order-info-card h6 {
        font-weight: 600;
        color: #dc3545;
    }

    .badge-status {
        font-size: 0.9rem;
        padding: 0.5em 1em;
        border-radius: 20px;
    }
</style>

<form action="function.php" method="POST">
    <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" onclick="location.href='orders.php'" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <input type="hidden" value="<?php echo $checkout_id; ?>" name="checkout_id">
                    <input type="hidden" value="<?php echo $email; ?>" name="email">
                    <input type="hidden" value="<?php echo $lastname . ' ' . $firstname; ?>" name="fullname">

                    <!-- Tabs -->
                    <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="customer-tab" data-bs-toggle="tab"
                                data-bs-target="#customer" type="button" role="tab"
                                aria-selected="true">Customer Info</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="product-tab" data-bs-toggle="tab"
                                data-bs-target="#product" type="button" role="tab"
                                aria-selected="false">Product Info</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="order-tab" data-bs-toggle="tab"
                                data-bs-target="#order_info" type="button" role="tab"
                                aria-selected="false">Order Info</button>
                        </li>
                    </ul>

                    <div class="tab-content border p-4 bg-white rounded-3 shadow-sm">
                        <!-- Customer Info -->
                        <div class="tab-pane fade show active text-dark" id="customer" role="tabpanel">
                            <div class="text-center mb-3">
                                <img src="<?php echo $profile_path; ?>" class="profile_path mb-3" alt="">
                                <h6 class="fw-bold mb-0"><?php echo $lastname . ' ' . $firstname; ?></h6>
                                <small class="text-muted">Customer</small>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="fw-semibold text-muted">Phone Number</label>
                                    <p class="text-dark mb-0"><?php echo $phone_number; ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-semibold text-muted">Email</label>
                                    <p class="text-dark mb-0"><?php echo $email; ?></p>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-semibold text-muted">Address</label>
                                    <p class="text-dark mb-0"><?php echo $address; ?></p>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="fw-semibold text-muted">Street</label>
                                    <p class="text-dark mb-0"><?php echo $street; ?></p>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label class="fw-semibold text-muted">Purok</label>
                                    <p class="text-dark mb-0"><?php echo $purok; ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Product Info -->
                        <div class="tab-pane fade" id="product" role="tabpanel">
                            <div class="splide mb-4">
                                <div class="splide__track">
                                    <ul class="splide__list">
                                        <?php
                                        $count_images = 0;
                                        $images = $conn->prepare("SELECT * FROM `images` WHERE `product_id` = ?");
                                        $images->bind_param("s", $product_id);
                                        $images->execute();
                                        $result_images = $images->get_result();
                                        if ($result_images->num_rows > 0) {
                                            while ($row_img = mysqli_fetch_assoc($result_images)) {
                                                $image_name = htmlspecialchars($row_img['image_name']);
                                                echo '<li class="splide__slide"><img src="../uploads/' . $image_name . '" class="img-fluid" alt=""></li>';
                                                $count_images++;
                                            }
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h6 class="text-muted"><?php echo $brand_name; ?></h6>
                                <h2 class="text-dark"><?php echo $product_name . ' (' . $category_name . ')'; ?></h2>
                                <h5 class="fw-bold text-danger mb-2">&#8369; <?php echo $price; ?></h5>
                                <p class="text-dark mb-1"><strong>Stocks:</strong> <?php echo $stocks; ?></p>
                                <p class="text-dark mb-0"><strong>Quantity Ordered:</strong> <?php echo $quantity; ?></p>
                            </div>
                        </div>

                        <!-- Order Info -->
                        <div class="tab-pane fade" id="order_info" role="tabpanel">
                            <div class="order-info-card">
                                <h6><i class="bi bi-receipt"></i> Order Summary</h6>
                                <p class="mb-1"><strong>Date:</strong> <?php echo $date; ?></p>
                                <p class="mb-1"><strong>Time:</strong> <?php echo $time; ?></p>
                                <p class="mb-1"><strong>Quantity:</strong> <?php echo $quantity; ?></p>
                                <p class="mb-1"><?php
                                    $total = str_replace(',', '', $total); // remove commas
                                    $total = (float)$total; // convert to float
                                    ?>
                                    <p class="mb-1"><strong>Total:</strong> ₱<?php echo number_format($total, 2); ?></p>
                                <p class="mb-1"><strong>Checkout ID:</strong> <?php echo $checkout_id; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer border-0 d-flex justify-content-between">
                    <div>
                        <button type="submit" name="disapproved_order" class="btn btn-danger me-2 <?php echo $hide; ?>">Disapprove</button>
                        <button type="submit" name="approved_order" class="btn btn-success <?php echo $hide; ?>">Approve</button>
                        <button type="submit" name="claimed_order" class="btn btn-success <?php echo $hide_status; ?>">Claim</button>
                        <button type="submit" name="unclaimed_order" class="btn btn-danger   <?php echo $hide_status; ?>">Unclaimed</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- JS Libraries -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/js/splide.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", () => {
    var splide = new Splide('.splide', {
        type: 'loop',
        padding: '2rem',
        arrows: <?= ($count_images > 1 ? 'true' : 'false') ?>,
        pagination: <?= ($count_images > 1 ? 'true' : 'false') ?>
    });
    splide.mount();
});
</script>

<?php if (isset($_SESSION['success'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      Swal.fire({
        title: "SUCCESS",
        html: `
          <p><?= $_SESSION['success']; ?></p>
          <dotlottie-wc
            src="https://lottie.host/c3e4bf0c-42ff-4725-8265-9dc66a592e66/fPjYSDeEWx.lottie"
            style="width: 100%;height: 300px;"
            autoplay
            loop
          ></dotlottie-wc>
        `,
        showConfirmButton: true,
        didOpen: () => {
          document.querySelector('.swal2-container').style.zIndex = "20000";
        }
      });
    });
  </script>
  <?php unset($_SESSION['success']); ?>
<?php endif; ?>


<!--sweet alert warning -->
<?php if (isset($_SESSION['warning'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      Swal.fire({
        title: "WARNING",
        html: `
        <p><?= $_SESSION['warning']; ?></p>
       <dotlottie-wc
        src="https://lottie.host/19e743f8-939a-476d-9121-db9abcb5f6b3/ARBOVXhFS7.lottie"
        style="width: 100%;height: 300px;z-index:100;"
        autoplay
        loop
      ></dotlottie-wc>
      `,
        showConfirmButton: true,
        didOpen: () => {
          document.querySelector('.swal2-container').style.zIndex = "20000";
        }
      });
    });
  </script>
  <?php unset($_SESSION['warning']); ?>
<?php endif; ?>


<!--sweet alert error -->
<?php if (isset($_SESSION['error'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      Swal.fire({
        title: "ERROR",
        html: `
        <p><?= $_SESSION['error']; ?></p>
        <dotlottie-wc
          src="https://lottie.host/11795bf7-f46b-4c94-969e-2a63ceabdf40/qVg8wFY1Q7.lottie"
          style="width: 100%;height: 300px;z-index:100;"
          autoplay
          loop
        ></dotlottie-wc>
      `,
        showConfirmButton: true,
        didOpen: () => {
          document.querySelector('.swal2-container').style.zIndex = "20000";
        }
      });
    });
  </script>
  <?php unset($_SESSION['error']); ?>
<?php endif; ?>


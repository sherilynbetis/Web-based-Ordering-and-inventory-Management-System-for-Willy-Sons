<?php

#error handler
error_reporting(E_ALL);
ini_set('display_errors', 1);


function customErrorHandler($errno, $errstr, $errfile, $errline) {
    $errorMessage = "Error [$errno]: $errstr in $errfile on line $errline";
    

    error_log($errorMessage . "\n", 3, "error_log.txt");


    echo "<div style='color: red; font-weight: bold;'>Something went wrong! Please try again later.</div>";

    return true;
}

#connection sa mysql
session_start();
 $conn = mysqli_connect("localhost","root","","willt_sons_db");
 if(!$conn){
    echo "not connected";
 }
 
#get user data
 // Get user data
 $profileko = " ";
if (isset($_SESSION['active_login'])) {
    $user_idko = $_SESSION['active_login'];

    $get_id = "SELECT * FROM `accounts` WHERE `user_id` = '$user_idko'";
    $result_data = mysqli_query($conn, $get_id);

    if ($result_data && mysqli_num_rows($result_data) > 0) {
        $id_row = mysqli_fetch_assoc($result_data);
        $lastnameko = htmlspecialchars($id_row['lastname']);
        $firstnameko = htmlspecialchars($id_row['firstname']);
        $phone_numberko = htmlspecialchars($id_row['phone_number']);
        $emailko = htmlspecialchars($id_row['email']);
        $profileko = htmlspecialchars($id_row['profile'] ?? '');
        $addressko = htmlspecialchars($id_row['address'] ?? 'Not Updated');
        $streetko = htmlspecialchars($id_row['street'] ?? 'Not Updated');
        $purokko = htmlspecialchars($id_row['purok'] ?? 'Not Updated');
        $fullnameko = $lastnameko . ' ' . $firstnameko;
    }
}


$profile_path = ($profileko === '') ? '../image/profile-icon.png' : "../uploads/$profileko";



  date_default_timezone_set("asia/manila");
 #get date today
$datetoday  = date("Y-m-d");
  #get year today
 $year = date("Y");
  #get time today

 $timetoday = date("h:i:s a");



<?php
#auto login
if (!isset($_SESSION['active_login']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];

    $find_data = $conn->prepare("SELECT * FROM `accounts` WHERE `token` = ?");
    $find_data->bind_param("s", $token);

    if ($find_data->execute()) {
        $result = $find_data->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $_SESSION['active_login'] = $row['user_id'];
            $_SESSION['user_type'] = $row['user_type'];

            // Optional: regenerate token on each login to prevent replay attacks
            $new_token = bin2hex(random_bytes(32));
            setcookie("remember_token", $new_token, time() + (7 * 24 * 60 * 60), "/", "", false, true);
            $update = $conn->prepare("UPDATE accounts SET token = ? WHERE user_id = ?");
            $update->bind_param("ss", $new_token, $row['user_id']);
            $update->execute();

            // Redirect
            if ($user_type === "Admin") {
                $_SESSION['success'] = "Welcome Admin";
                header('Location: admin');
            } elseif ($user_type === "Customer") {
                $_SESSION['success'] = "Welcome Customer";
                header('Location: customer');
            } else {
                header('Location: login.php');
            }
            exit;
    }
    }
}

?>

<?php 
include 'index.php'; 
?>

<style>
:root {
  --theme-red: #d62828;
  --theme-red-dark: #b71c1c;
  --theme-light: #fff5f5;
  --text-dark: #212529;
}

body {
  background-color: #f9f9f9;
}

.mycart-section .img-icon {
  width: 30px;
}

.modal-content {
  border-radius: 15px;
  overflow: hidden;
  border: none;
  box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
}

.modal-header {
  background-color: var(--theme-red);
  color: white;
  border-bottom: none;
  padding: 1rem 1.5rem;
}

.modal-title img {
  width: 35px;
  filter: brightness(0) invert(1);
}

.btn-close {
  filter: invert(1);
}

.card {
  border: none;
  border-radius: 10px;
  background: var(--theme-light);
  transition: 0.2s ease;
}

.card:hover {
  background: #fff;
  box-shadow: 0 2px 12px rgba(214, 40, 40, 0.2);
}

.card img {
  border-radius: 10px;
}

.quantity-box {
  display: flex;
  justify-content: center;
  align-items: center;
}

.quantity-box .btn {
  color: var(--theme-red);
  border-color: var(--theme-red);
}

.quantity-box .btn:hover {
  background-color: var(--theme-red);
  color: #fff;
}

.totalInput {
  border: none;
  background: transparent;
  font-weight: 600;
  color: var(--theme-red);
}

.text-muted {
  font-size: 0.9rem;
}

.text-end h4 {
  color: var(--theme-red-dark);
  font-weight: 700;
}

.btn-danger {
  background-color: var(--theme-red);
  border: none;
  font-weight: 600;
  transition: 0.2s ease;
}

.btn-danger:hover {
  background-color: var(--theme-red-dark);
}

.modal-footer {
  background-color: #fff5f5;
  border-top: none;
}

@media (max-width: 768px) {
  .col-md-6 img {
    max-width: 100px;
  }
}
</style>

<main>
  <section class="mycart-section">
    <form action="function.php" method="POST">
      <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header border-0">
              <h1 class="modal-title fs-5 fw-bold" id="staticBackdropLabel">
                <img src="../image/checkout-icon.png" class="img-icon me-2" alt=""> Buy Now
              </h1>
              <button type="button" onclick="location.href='index.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">
              <?php
              $grand_total = 0;

              if (isset($_POST['cart_id']) && is_array($_POST['cart_id'])) {
                foreach ($_POST['cart_id'] as $id => $value) {
                  $get_cart_info = $conn->prepare("SELECT * FROM `cart` WHERE `cart_id` = ?");
                  $get_cart_info->bind_param("s", $id);
                  $get_cart_info->execute();
                  $result_cart = $get_cart_info->get_result();

                  if ($row_cart = $result_cart->fetch_assoc()) {
                    $product_id = $row_cart['product_id'];
                    $cart_id = $row_cart['cart_id'];
                    $quantity = (int)$row_cart['quantity'];

                    // ✅ If quantity is 0, make it 1 before calculation
                    if ($quantity < 1) {
                      $quantity = 1;
                    }

                    $get_product = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
                    $get_product->bind_param("s", $product_id);
                    $get_product->execute();
                    $result_product = $get_product->get_result();

                    if ($row_pro = $result_product->fetch_assoc()) {
                      $product_name = htmlspecialchars($row_pro['product_name']);
                      $price = (float)str_replace([',', '₱'], '', $row_pro['price']);
                      $stocks = (int)$row_pro['stocks'];
                      $subtotal = $price * $quantity;
                      $grand_total += $subtotal;

                      $images = $conn->prepare("SELECT * FROM `images` WHERE `product_id` = ? LIMIT 1");
                      $images->bind_param("s", $product_id);
                      $images->execute();
                      $result_image = $images->get_result();
                      $image_name = ($row_img = $result_image->fetch_assoc()) ? htmlspecialchars($row_img['image_name']) : 'no-image.png';
              ?>
                      <input type="hidden" name="product_id[<?php echo $id; ?>]" value="<?php echo $product_id; ?>">

                    <div class="card mb-3 p-3">
                      <div class="row g-3 align-items-center">
                        <div class="col-md-6 d-flex align-items-center gap-3">
                          <img src="../uploads/<?php echo $image_name; ?>" alt="" class="img-fluid rounded" style="max-width:120px;">
                          <div>
                            <h5 class="mb-1 fw-bold"><?php echo $product_name; ?></h5>
                            <p class="mb-1 text-muted">₱<?php echo number_format($price, 2); ?> each</p>
                          </div>
                        </div>

                        <div class="col-md-3 text-center">
                          <?php if ($stocks > 0): ?>
                            <div class="input-group quantity-box">
                              <button class="btn btn-outline-danger" type="button" onclick="changeQty(this, -1, <?php echo $price; ?>)">−</button>
                              <input type="text" class="form-control text-center qtyInput" 
                                    name="quantity[<?php echo $id; ?>]" 
                                    value="<?php echo ($quantity > 0) ? $quantity : 1; ?>" 
                                    min="1" max="<?php echo $stocks; ?>">
                              <button class="btn btn-outline-danger" type="button" onclick="changeQty(this, 1, <?php echo $price; ?>)">+</button>
                            </div>
                          <?php else: ?>
                            <p class="text-danger fw-semibold mt-2">Out of stock</p>
                          <?php endif; ?>
                        </div>

                        <div class="col-md-3 text-end d-flex">
                          ₱<input type="text" class="form-control text-end totalInput fw-bold" 
                                  name="total[<?php echo $id; ?>]" 
                                  value="<?php echo number_format($subtotal, 2); ?>" readonly>
                        </div>
                      </div>
                    </div>


              <?php
                    }
                  }
                }
              }
              ?>
              <hr>
              <div class="text-end pe-2">
                <h4 class="fw-bold mb-0">Grand Total: 
                  <span class="text-danger">₱<span id="grandTotal"><?php echo number_format($grand_total, 2); ?></span></span>
                </h4>
              </div>
            </div>

            <div class="modal-footer border-0 justify-content-end">
              <button type="submit" name="checkout_total" class="btn btn-danger px-5 py-2 rounded-pill shadow">Proceed to Checkout</button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </section>
</main>

<script>
function changeQty(btn, val, price) {
  const parent = btn.closest('.quantity-box');
  const input = parent.querySelector('.qtyInput');
  const totalInput = parent.closest('.row').querySelector('.totalInput');

  let current = parseInt(input.value) || 1;
  let newVal = current + val;

  if (newVal < 1) newVal = 1; // ✅ Prevent zero
  input.value = newVal;

  const subtotal = price * newVal;
  totalInput.value = subtotal.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  updateGrandTotal();
}

document.querySelectorAll('.qtyInput').forEach(input => {
  input.addEventListener('input', function() {
    let val = parseInt(this.value);
    if (isNaN(val) || val < 1) val = 1; // ✅ Always 1 minimum
    this.value = val;

    const btn = this.closest('.quantity-box').querySelector('button');
    const match = btn.getAttribute('onclick').match(/, ([\d.]+)\)/);
    const price = match ? parseFloat(match[1]) : 0;

    const totalInput = this.closest('.row').querySelector('.totalInput');
    const subtotal = price * val;
    totalInput.value = subtotal.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

    updateGrandTotal();
  });

  // ✅ Auto-correct to 1 when leaving the input
  input.addEventListener('blur', function() {
    if (this.value === '' || parseInt(this.value) < 1) {
      this.value = 1;
      const event = new Event('input');
      this.dispatchEvent(event);
    }
  });
});

function updateGrandTotal() {
  let total = 0;
  document.querySelectorAll('.totalInput').forEach(el => {
    total += parseFloat(el.value.replace(/,/g, '')) || 0;
  });
  document.getElementById('grandTotal').textContent = total.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
</script>

<?php 
    include 'index.php';
    if(isset($_GET['product_id'])){
        $product_id = $_GET['product_id'] ?? '';
    }
    $get= $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get->bind_param("s",$product_id);
    $get->execute();
    $result_products = $get->get_result();
    if($result_products->num_rows>0){
        while($row_products = mysqli_fetch_assoc($result_products)){
            $product_name = htmlspecialchars($row_products['product_name']);
            $brand_name   = htmlspecialchars($row_products['brand_name']);
            $category     = htmlspecialchars($row_products['category']);
            $status       = htmlspecialchars($row_products['status']);
            $price        = htmlspecialchars($row_products['price']);
            $stocks       = htmlspecialchars($row_products['stocks']);
           
        }
    }
    
    $total = $price;
    $get_category = $conn->prepare("SELECT * FROM `categories` WHERE `category_id` = ?");
    $get_category->bind_param("s",$category);
    $get_category->execute();
    $result_cat = $get_category->get_result();
    if($result_cat->num_rows>0){
        while($row_cat = mysqli_fetch_assoc($result_cat)){
            $category_name = htmlspecialchars($row_cat['category_name'] ?? 'No Category');
        }
    }
?>
<style>
    .add-cart-section .featured-img {
        width: 100%;
        aspect-ratio: 1/1;
        object-fit: cover;
        border-radius: .5rem;
    }
    .add-cart-section .img-icon {
        width: 28px;
    }
    .cart-price {
        font-size: 1.2rem;
        font-weight: 600;
        color: #dc3545; /* Bootstrap red */
    }
    .stock-status {
        font-size: .9rem;
    }
    .quantity-box {
        max-width: 140px;
    }
</style>

<!-- Bootstrap2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Splide CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/css/splide.min.css">
<!-- Bootstrap2 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Splide JS -->
<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/js/splide.min.js"></script>

<main>
<section class="add-cart-section">
  <form action="function.php" method="POST">
    <div class="offcanvas offcanvas-end" 
       id="system_offcanva" 
       data-bs-scroll="true" 
       data-bs-backdrop="static" 
       data-bs-keyboard="false"
       tabindex="-1" 
       aria-labelledby="offcanvasWithBothOptionsLabel">

       <input type="hidden" value="<?php echo $product_id; ?>" name="product_id">
       <input type="hidden" value="<?php echo $stocks; ?>" name="stocks">
       <input type="hidden" value="buy" name="type">

    <div class="offcanvas-header border-bottom">
      <h5 class="offcanvas-title fw-bold" id="offcanvasWithBothOptionsLabel">
        <img src="../image/checkout-icon.png" class="img-icon me-2" alt=""> Buy Now
      </h5>
      <button type="button" onclick="location.href='index.php'" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>

    <div class="offcanvas-body">
      <div class="splide mb-3">
        <div class="splide__track">
          <ul class="splide__list">
            <?php
            $count_images = 0;
            $images = $conn->prepare("SELECT * FROM `images` WHERE `product_id` = ?");
            $images->bind_param("s", $product_id);
            $images->execute();
            $result_images = $images->get_result();
            if ($result_images->num_rows > 0) {
                while ($row_img = mysqli_fetch_assoc($result_images)) {
                    $image_name = htmlspecialchars($row_img['image_name']);
                    echo '<li class="splide__slide"><img src="../uploads/' . $image_name . '" class="featured-img" alt=""></li>';
                    $count_images++;
                }
            }
            ?>
          </ul>
        </div>
      </div>

      <!-- Product Details -->
      <h5 class="fw-bold mb-1"><?php echo $brand_name . ' ' . $product_name; ?></h5>
      <p class="text-muted mb-2"><?php echo ucfirst($category_name); ?></p>
      <p class="cart-price mb-1">&#8369; <?php echo number_format($price, 2); ?></p>
      <p class="stock-status <?php echo ($stocks > 0 ? 'text-success' : 'text-danger'); ?>">
        <?php echo ($stocks > 0) ? "In Stock ($stocks available)" : "Out of Stock"; ?>
      </p>

      <!-- Quantity + Add to Cart -->
      <?php if ($stocks > 0): ?>
    <div class="d-flex align-items-center mt-3 justify-content-end">
      <div class="input-group quantity-box me-3">
        <button class="btn btn-outline-secondary" type="button" onclick="changeQty(-1)">-</button>
        <input type="text" class="form-control text-center" name="quantity" id="qtyInput" value="1">
        <button class="btn btn-outline-secondary" type="button" onclick="changeQty(1)">+</button>
      </div>
    </div>

      <?php endif; ?>

         <div>
      <hr>
      <h3 class="d-flex">
        TOTAL:
        <input type="text" id="result" name="total"
          value="<?php echo number_format((float)$total, 2); ?>"
          class="form-control" readonly>
      </h3>
</div>
      <input type="submit" name="buy_now" value="BUY NOW" class="btn btn-dark w-100">
    </div>
  </div>
  </form>
</section>
</main>

<script>
const price = <?php echo $price; ?>;
const maxStock = <?php echo $stocks; ?>; 
const qtyInput = document.getElementById("qtyInput");
const result = document.getElementById("result");

function changeQty(val) {
  let current = parseInt(qtyInput.value) || 1;
  let newVal = current + val;

  // ✅ Prevent below 1 or above stock
  if (newVal < 1) newVal = 1;
  if (newVal > maxStock) newVal = maxStock;

  qtyInput.value = newVal;
  calculateTotal();
}

qtyInput.addEventListener("input", () => {
  let value = parseInt(qtyInput.value);
  if (isNaN(value) || value < 1) value = 1;

  // ✅ Prevent entering more than available stock
  if (value > maxStock) value = maxStock;

  qtyInput.value = value;
  calculateTotal();
});

function calculateTotal() {
  const total = price * parseInt(qtyInput.value);
  result.value = total.toLocaleString(undefined, { 
    minimumFractionDigits: 2, 
    maximumFractionDigits: 2 
  });
}

// Initialize total
calculateTotal();
</script>
<script>
  document.addEventListener("DOMContentLoaded", () => {
    var splide = new Splide('.splide', {
      type   : 'loop',
      padding: '2rem',
      arrows : <?= ($count_images > 1 ? 'true' : 'false') ?>,
      pagination : <?= ($count_images > 1 ? 'true' : 'false') ?>
    });
    splide.mount();

    // Auto show Offcanvas
    var offcanvasElement = document.getElementById('system_offcanva');
    var bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
    bsOffcanvas.show();
  });


</script>

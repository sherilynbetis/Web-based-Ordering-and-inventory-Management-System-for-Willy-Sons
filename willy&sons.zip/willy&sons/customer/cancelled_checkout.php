<?php

include 'index.php';

if(isset($_GET['checkout_id'])){
    $checkout_id = $_GET['checkout_id'] ?? '';
}
?>
<main>
    <section class="remove-cart-section">
      <form action="function.php" method="POST">
          <!-- Modal -->
        <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header border-0">
                <input type="hidden" name="checkout_id" value="<?php echo $checkout_id; ?>">
            </div>
            <div class="modal-body text-center">
                Are Your sure to Cancelled this Checkout?
            </div>
            <div class="modal-footer border-0">
                <button onclick="location.href='checkout.php'" type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="submit" name="cancelled_checkout" class="btn btn-danger">Yes</button>
            </div>
            </div>
        </div>
        </div>
      </form>
    </section>
</main>
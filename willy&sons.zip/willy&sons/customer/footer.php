

  <?php include '../alerts.php'; ?>
  <script src="../js/scripts.js"></script>
  <script src="../js/sweet_alert.js"></script>
  <script src="../js/bootstrap.bundle.min.js"></script>
</body>
</html>
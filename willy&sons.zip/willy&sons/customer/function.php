<?php
 include '../config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

 if(isset($_POST['add_to_cart'])){
    $product_id = $_POST['product_id'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $total = $_POST['total'] ?? '';

    $stocks = 0;
    $get_stocks = $conn->prepare("SELECT stocks FROM products WHERE product_id = ? AND stocks <= ?");
    $get_stocks->bind_param("si",$product_id,$stocks);
    $get_stocks->execute();
    $result = $get_stocks->get_result();
    if($result->num_rows>0){
        $_SESSION['error'] = "Product 0 Stocks";
        header("location:add_to_cart.php?product_id=$product_id");
        exit;
    }
    
    $cart_id = rand();
    $insert=$conn->prepare("INSERT INTO cart (cart_id,`user_id`,`product_id`,`date`,`time`,`quantity`,`total`) VALUES (?,?,?,?,?,?,?)");
    $insert->bind_param("sssssss",$cart_id,$user_idko,$product_id,$datetoday,$timetoday,$quantity,$total);
    $insert->execute();
    $_SESSION['success'] = "Successfully Added to Cart";
    header("location:index.php");
    exit;
 }

 if(isset($_POST['buy_now'])){
    $product_id = $_POST['product_id'] ?? '';
    $quantity = $_POST['quantity'] ?? '';
    $total = $_POST['total'] ?? '';
    $type = $_POST['type'] ?? '';
    $cart_id = $_POST['cart_id'] ?? '';
    $tomorrow = date("Y-m-d", strtotime("+1 day"));

    $check_product =  $conn->prepare("SELECT * FROM products WHERE product_id = ?");
    $check_product->bind_param("s",$product_id);
    $check_product->execute();
    $result_product = $check_product->get_result();
    if($result_product->num_rows>0){
        while($row_pro = mysqli_fetch_assoc($result_product)){
            $stocks = htmlspecialchars($row_pro['stocks']);
        }
    }

    if((int)$stocks === 0){
        $_SESSION['error'] = "Product 0 Stocks";
        header("location:buy_now.php?product_id=$product_id");
        exit;
    }
    elseif($quantity > $stocks){
        $_SESSION['error'] = "Quantity Higher than Stocks";
        header("location:buy_now.php?product_id=$product_id");
        exit;
    }else{
  
    if($type === 'buy'){
        $checkout_id = rand();
        $status = 'Pending';
        $insert=$conn->prepare("INSERT INTO checkout (checkout_id,`user_id`,`product_id`,`date`,`time`,`quantity`,`total`,`status`,`expiration_date`,`expiration_time`) VALUES (?,?,?,?,?,?,?,?,?,?)");
        $insert->bind_param("ssssssssss",$checkout_id,$user_idko,$product_id,$datetoday,$timetoday,$quantity,$total,$status,$tomorrow,$timetoday);
        $insert->execute();
        $_SESSION['success'] = "Succesfully Checkout";
        header("location:index.php");
        exit;
    }else{
        $checkout_id = rand();
        $status = 'Pending';
        $insert=$conn->prepare("INSERT INTO checkout (checkout_id,`user_id`,`product_id`,`date`,`time`,`quantity`,`total`,`status`,`expiration_date`,`expiration_time`) VALUES (?,?,?,?,?,?,?,?,?,?)");
        $insert->bind_param("ssssssssss",$checkout_id,$user_idko,$product_id,$datetoday,$timetoday,$quantity,$total,$status,$tomorrow,$timetoday);
        $insert->execute();

        $delete = $conn->prepare("DELETE FROM cart WHERE  cart_id = ?");
        $delete->bind_param("s",$cart_id);
        $delete->execute();

        $_SESSION['success'] = "Succesfully Checkout";
        header("location:index.php");
        exit;
    }
    
          
    }

 }


 
if (isset($_POST['update_info'])) {
    $lastname     = $_POST['lastname'];
    $firstname    = $_POST['firstname'];
    $phone_number = $_POST['phone_number'];
    $email        = $_POST['email'];
    $address      = $_POST['address'];
    $street       = $_POST['street'];
    $purok        = $_POST['purok'];

    $profile     = $_FILES['profile']['name'] ?? '';
    $profile_tmp = $_FILES['profile']['tmp_name'] ?? '';
    $destination = '../uploads/' . $profile;

    // ✅ Check duplicate email
    $get_email = $conn->prepare("SELECT * FROM accounts WHERE email = ? AND user_id != ?");
    $get_email->bind_param("ss", $email, $user_idko);
    $get_email->execute();
    if ($get_email->get_result()->num_rows > 0) {
        $_SESSION['error'] = "Email Already Taken";
        header("location:profile_edit.php");
        exit;
    }

    // ✅ Check duplicate phone
    $get_number = $conn->prepare("SELECT * FROM accounts WHERE phone_number = ? AND user_id != ?");
    $get_number->bind_param("ss", $phone_number, $user_idko);
    $get_number->execute();
    if ($get_number->get_result()->num_rows > 0) {
        $_SESSION['error'] = "Phone Number Already Taken";
        header("location:profile_edit.php");
        exit;
    }

    // ✅ If profile uploaded
    if (!empty($profile) && move_uploaded_file($profile_tmp, $destination)) {
        $update = $conn->prepare("UPDATE accounts 
            SET lastname`=?, firstname`=?, phone_number`=?, email`=?, 
                profile`=?, address`=?, street`=?, purok`=? 
            WHERE `user_id`=?");
        $update->bind_param("sssssssss", $lastname, $firstname, $phone_number, $email, $profile, $address, $street, $purok, $user_idko);
    } else {
        // ✅ Update without profile
        $update = $conn->prepare("UPDATE accounts 
            SET lastname`=?, firstname`=?, phone_number`=?, email`=?, 
                address`=?, street`=?, `purok`=? 
            WHERE `user_id`=?");
        $update->bind_param("ssssssss", $lastname, $firstname, $phone_number, $email, $address, $street, $purok, $user_idko);
    }

    $update->execute();
    $_SESSION['success'] = "Successfully Updated";
    header("location:profile.php");
    exit;
}

if(isset($_POST['remove_product'])){
    $cart_id = $_POST['cart_id'];

    $delete = $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
    $delete->bind_param("s",$cart_id);
    $delete->execute();

    $_SESSION['success'] = "Successfully Deleted";
    header("location:cart.php");
    exit;
}


if(isset($_POST['cancelled_checkout'])){
    $checkout_id = $_POST['checkout_id'] ?? '';
    $status = "Cancelled";
    $update = $conn->prepare("UPDATE checkout SET status = ? WHERE checkout_id = ?");
    $update->bind_param("ss",$status,$checkout_id);
    $update->execute();
    $_SESSION['success'] ="Successfully Cancelled";
    header("location:checkout.php");
    exit;
}
if (isset($_POST['checkout_total'])) {
    $product_ids = $_POST['product_id'] ?? [];
    $quantities = $_POST['quantity'] ?? [];
    $totals = $_POST['total'] ?? [];
    $status = 'Pending';
    $tomorrow = date("Y-m-d", strtotime("+1 day"));
    $errors = [];

    foreach ($product_ids as $cart_id => $product_id) {
        $quantity = isset($quantities[$cart_id]) ? (int)$quantities[$cart_id] : 1;
        $total = isset($totals[$cart_id]) ? str_replace(',', '', $totals[$cart_id]) : 0;

        // Check product stock
        $check_product = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
        $check_product->bind_param("s", $product_id);
        $check_product->execute();
        $result_check = $check_product->get_result();

        if ($result_check->num_rows > 0) {
            $row_pro = $result_check->fetch_assoc();
            $stocks = (int)$row_pro['stocks'];

            // Check if stock is available
            if ($stocks <= 0) {
                $errors[] = "Product '{$product_id}' is out of stock.";
                continue;
            }

            // Check if quantity requested exceeds available stock
            if ($quantity > $stocks) {
                $errors[] = "Insufficient stock for '{$product_id}'. Available: $stocks, Requested: $quantity.";
                continue;
            }

            // Process checkout
            $checkout_id = rand();
            $insert = $conn->prepare("INSERT INTO checkout 
                (checkout_id,`user_id`,`product_id`,`date`,`time`,`quantity`,`total`,`status`,`expiration_date`,`expiration_time`) 
                VALUES (?,?,?,?,?,?,?,?,?,?)");
            $insert->bind_param("ssssssssss", $checkout_id, $user_idko, $product_id, $datetoday, $timetoday, $quantity, $total, $status, $tomorrow, $timetoday);
            $insert->execute();

            // Update stock (subtract purchased quantity)
            $new_stock = $stocks - $quantity;
            $update_stock = $conn->prepare("UPDATE products SET stocks = ? WHERE product_id = ?");
            $update_stock->bind_param("is", $new_stock, $product_id);
            $update_stock->execute();

            // Delete from cart
            $delete = $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
            $delete->bind_param("s", $cart_id);
            $delete->execute();
        } else {
            $errors[] = "Product '{$product_id}' not found.";
        }
    }

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("location: cart.php");
        exit;
    } else {
        $_SESSION['success'] = "Successfully checked out!";
        header("location: index.php");
        exit;
    }
}


if(isset($_POST['delete_cart'])){
if (isset($_POST['cart_id']) && is_array($_POST['cart_id'])) {
    foreach ($_POST['cart_id'] as $id => $value) {
        
            $delete= $conn->prepare("DELETE FROM cart WHERE cart_id = ?");
            $delete->bind_param("s",$id);
            $delete->execute();
    }
}
    $_SESSION['success'] = "Succesfully Deleted";
header("location:index.php");
exit;
}
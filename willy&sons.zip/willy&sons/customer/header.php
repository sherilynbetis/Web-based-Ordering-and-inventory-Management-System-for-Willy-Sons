<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy and Sons</title>
  <link rel="stylesheet" href="../css/customer.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="shortcut icon" href="../image/logo.jpg" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <script src="js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<?php
   include '../config.php';
   include 'logout_modal.php';
   if(!isset($_SESSION['active_login'])){
    echo "<script>location.href='../index.php';</script>";
        exit;
   }
?>

<style>
body{
    background:#f2f2f2;
}
.navbar{
    background:white;
    position:fixed;
    width:100%;
    z-index: 100;
}
.navbar .system-logo{
    width:100px;
}

.navbar .img-icon{
    width:20px;
}

.navbar .navbar-brand{
    font-weight:900;
    color:#c22629;
}

.navbar .mobile-link{
    display:none;
}


.navbar .navbar-nav{
    width:100%  !important;
    display:flex !important;
    justify-content: end  !important;
    align-items: end  !important;
}

.navbar .hamburger-icon{
    width:30px;
}

.navbar .profile-icon{
  width:20px;
  aspect-ratio: 1/1;
}

.search_parent{
  width:50%;
}

@media(max-width:1300px){
  .search_parent{
    width:30%;
  }
}
@media(max-width:1022px){
  .search_parent{
    width:25%;
  }
}

@media(max-width:991px){

    .navbar .mobile-link{
    display:block;
}


.navbar .navbar-nav{
    width:100%  !important;
    display:flex !important;
    justify-content: start  !important;
    align-items: start  !important;
}
.navbar .nav-item:nth-child(5){
    margin-top: 20px;
    width:100%;
}


  .search_parent{
    width:100%;
  }


}

 .offcanvas .all_brands li{
    list-style: none;
    font-weight:bold;
  }

  .offcanvas .all_brands li:hover{
      color:#c72429;
      cursor: pointer;
  }
</style>

<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="../image/logo.png" class="system-logo" alt=""> Willy & Sons</a>
    <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <img src="../image/hamburger.png" class="hamburger-icon" alt="">
    </button>
    <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav  mb-2 mb-lg-0 ">
        <li class="nav-item search_parent">
          <form action="" method="GET" class="mb-3">
              <div class="input-group flex-nowrap">
                  <input type="text" name="search" class="form-control" placeholder="Search product..."
                      value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                  <button type="submit" name="search_button" class="input-group-text" id="addon-wrapping">
                      <i class="bi bi-search"></i>
                  </button>
              </div>
          </form>
      </li>
        <li class="nav-item ">
            <a href="checkout.php" class="nav-link text-dark"><img src="../image/checkout-icon.png" class="img-icon" alt=""> Checkout</a>
        </li>    
        <li class="nav-item ">
            <a href="cart.php" class="nav-link text-dark"><img src="../image/my_cart-icon.png" class="img-icon" alt=""> Cart <span class="bg-secondary rounded-3 p-1" id="my_cart"></span></a>
        </li>    
        <li class="nav-item ">
            <a href="history.php" class="nav-link text-dark"><img src="../image/clock.png" class="img-icon" alt=""> History</a>
        </li>
         <li class="nav-item ">
            <a href="profile.php" class="nav-link text-dark"><img src="../image/profile-icon.png" class="img-icon" alt=""> Profile</a>
        </li>   
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-dark" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="<?php echo $profile_path; ?>" class="profile-icon" alt="">
            <?php echo $lastnameko; ?>
          </a>
          <ul class="dropdown-menu">
           <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal" ><img src="../image/logout.png" class="img-icon" alt=""> Sign Out</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>


<div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Categories</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
      <div class="sidebar">
        <!--accordion-->
        <div class="accordion" id="accordionExample">

          <!-- ALL BRANDS -->
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="accordion-button category-filter-all" type="button" 
                      data-bs-toggle="collapse" 
                      data-bs-target="#collapseOne" 
                      aria-expanded="true" 
                      aria-controls="collapseOne">
                All Brands
              </button>
            </h2>
            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <ul class="all_brands">
                  <?php
                  $get_all_products = $conn->prepare("SELECT DISTINCT brand_name FROM products");
                  $get_all_products->execute();
                  $result_products = $get_all_products->get_result();
                  if ($result_products->num_rows > 0) {
                    while ($row_products = mysqli_fetch_assoc($result_products)) {
                      $brand_name = htmlspecialchars($row_products['brand_name']);
                      ?>
                      <li class="brand-filter" data-brand="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></li>
                      <?php
                    }
                  }
                  ?>
                </ul>
              </div>
            </div>
          </div>

          <!-- CATEGORIES -->
          <?php 
          $get_categories = $conn->prepare("SELECT * FROM categories");
          $get_categories->execute();
          $result_categories = $get_categories->get_result();
          if ($result_categories->num_rows > 0) {
            while ($row_categories = mysqli_fetch_assoc($result_categories)) {
              $category_name = htmlspecialchars($row_categories['category_name']);
              $category_id  = htmlspecialchars($row_categories['category_id']);
              $accordion_id = "cat_" . $category_id;
          ?>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading-<?php echo $accordion_id; ?>">
              <button class="accordion-button collapsed category-filter" type="button"
                      data-category="<?php echo $category_id; ?>"
                      data-bs-toggle="collapse"
                      data-bs-target="#<?php echo $accordion_id; ?>"
                      aria-expanded="false"
                      aria-controls="<?php echo $accordion_id; ?>">
                <?php echo $category_name; ?>
              </button>
            </h2>
            <div id="<?php echo $accordion_id; ?>" class="accordion-collapse collapse"
                 aria-labelledby="heading-<?php echo $accordion_id; ?>"
                 data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <ul class="all_brands">
                  <?php
                  $get_its_brand = $conn->prepare("SELECT DISTINCT brand_name FROM products WHERE category = ?");
                  $get_its_brand->bind_param("s", $category_id);
                  $get_its_brand->execute();
                  $result_brand = $get_its_brand->get_result();
                  if ($result_brand->num_rows > 0) {
                    while ($row_its_brand = mysqli_fetch_assoc($result_brand)) {
                      $brand_name = htmlspecialchars($row_its_brand['brand_name']);
                      ?>
                      <li class="brand-filter" data-brand="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></li>
                      <?php
                    }
                  }
                  ?>
                </ul>
              </div>
            </div>
          </div>
          <?php
            }
          }
          ?>
        </div>
        </div>
        <!--end accordion-->
      </div>
  </div>
</div>

<script>
  /*ajax pooliing real time */
document.addEventListener("DOMContentLoaded", () => {
      function fetchOwnerRequests() {
    $.ajax({
        url: "realtime_cart.php", 
        method: "GET",
        success: function(response) {
            $('#my_cart').html(response);
        },
        error: function() {
            $('#my_cart').html("Failed to load data.");
        }
    });
}

// Fetch initially
fetchOwnerRequests();

// Poll every 5 seconds
setInterval(fetchOwnerRequests, 1000);
});
</script>
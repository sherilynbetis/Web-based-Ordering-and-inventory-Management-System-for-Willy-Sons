<?php 
    include 'index.php'; 

?>

<style>
.mycheckout-section .img-icon{
    width:30px;
}
</style>

<main>
    <section class="mycheckout-section">
        <!-- Modal -->
        <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
            <div class="modal-header border-0">
                <h1 class="modal-title fs-5 fw-bold" id="staticBackdropLabel"><img src="../image/clock.png" class="img-icon" alt=""> My History</h1>
                <button type="button" onclick="location.href='index.php'" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="overflow-auto">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Product Image</th>
                            <th>Brand</th>
                            <th>Product</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                     <?php
                        $Pending = 'Pending';
                        $Approved = 'Approved';

                        $get_cart = $conn->prepare("
                            SELECT * 
                            FROM `checkout` 
                            WHERE `user_id` = ? 
                            AND (`status` != ? AND `status` != ?)
                            ORDER BY `date`
                        ");

                        $get_cart->bind_param("sss", $user_idko, $Pending, $Approved);
                        $get_cart->execute();
                        $result_cart = $get_cart->get_result();

                        if ($result_cart->num_rows > 0) {
                            while ($row_cart = $result_cart->fetch_assoc()) {
                                $checkout_id = htmlspecialchars($row_cart['checkout_id']);
                                $product_id  = htmlspecialchars($row_cart['product_id']);
                                $date        = htmlspecialchars($row_cart['date']);
                                $time        = htmlspecialchars($row_cart['time']);
                                $quantity    = htmlspecialchars($row_cart['quantity']);
                                $total       = htmlspecialchars($row_cart['total']);
                                $status      = htmlspecialchars($row_cart['status']);
                            $display = ($status === 'Pending') ? ' ' : 'd-none';

                            // ✅ Get product details
                            $get_products = $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
                            $get_products->bind_param("s", $product_id);
                            $get_products->execute();
                            $result_products = $get_products->get_result();

                            if ($result_products->num_rows > 0) {
                                $row_pro = mysqli_fetch_assoc($result_products);
                                $product_name = htmlspecialchars($row_pro['product_name'] ?? '');
                                $brand_name   = htmlspecialchars($row_pro['brand_name'] ?? '');
                                $category     = htmlspecialchars($row_pro['category'] ?? '');

                                // ✅ Get category name
                                $get_category = $conn->prepare("SELECT category_name FROM `categories` WHERE `category_id` = ?");
                                $get_category->bind_param("s", $category);
                                $get_category->execute();
                                $result_cat = $get_category->get_result();
                                $category_name = ($result_cat->num_rows > 0) ? htmlspecialchars($result_cat->fetch_assoc()['category_name']) : 'N/A';

                                // ✅ Get product image
                                $get_image = $conn->prepare("SELECT image_name FROM `images` WHERE `product_id` = ? LIMIT 1");
                                $get_image->bind_param("s", $product_id);
                                $get_image->execute();
                                $result_image = $get_image->get_result();
                                $image_name = ($result_image->num_rows > 0) ? htmlspecialchars($result_image->fetch_assoc()['image_name']) : 'no-image.png';
                                ?>
                                
                                <tr>
                                <td><img src="../uploads/<?php echo $image_name; ?>" alt="" width="60"></td>
                                <td><?php echo $brand_name; ?></td>
                                <td><?php echo $product_name; ?></td>
                                <td><?php echo $category_name; ?></td>
                                <td><?php echo $date; ?></td>
                                <td><?php echo $time; ?></td>
                                <td><?php echo $quantity; ?></td>
                                <td><?php echo $total; ?></td>
                                <td><?php echo $status; ?></td>
                                </tr>

                                <?php
                            }
                            }
                        } else {
                            echo "<tr><td colspan='9' class='text-center'>No items in cart</td></tr>";
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer border-0">
                <!--footer-->
            </div>
            </div>
        </div>
        </div>
    </section>
</main>


<?php include 'header.php'; ?>


<style>
  .product-section{
    padding:100px 0;
  }

  .product-section .sidebar{
    width:500px;
  }

  .product-section .main-content{
    width:100%;
  }

    .product-section .box_products{
      box-shadow: -1px -1px 10px white, 1px 1px 10px gray;
      border-radius: 15px;
      transition-timing-function: ease-in-out;
      cursor: pointer;
      transition: 1s;
      transition-timing-function: ease-in-out;
      background:white;
    }

  

    .product-section .box_products:hover{
      transform: translateY(-10px);
      transition: 1s;
    }

  .product-section .box_products img{
    width:100%;
    aspect-ratio: 1/1;
    border-top-right-radius:15px;
    border-top-left-radius:15px;
  }


  .product-section .box_products .details-con{
    padding:20px;
  }

  .product-section .box_products .img-con{
    position: relative;
    overflow: hidden;
  }

    .product-section .box_products:hover .img-con::before{
      content: "Quick View";
      font-weight: bold;
    backdrop-filter: blur(0px) saturate(180%);
    -webkit-backdrop-filter: blur(0px) saturate(180%);
    background-color: rgba(23, 22, 22, 0.51);
      display: flex;
      justify-content: center;
      align-items: center;
      color:white;
         border-top-right-radius:15px;
    border-top-left-radius:15px;
      transition: 1s;     height: 100%;
      width:100%;
      padding:20px;
      position:absolute;
    border: 1px solid rgba(209, 213, 219, 0.3);

    }

  .product-section .box_products .img-con p{
      position: absolute;
      top:20px;
      left:20px;
      background:#c72429;
      color:white;
      padding:5px 15px;
      border-radius: 20px;
      z-index: 20;
  } 


  .product-section .box_products .action-buttons{
    display: flex;
    justify-content: end;
    gap:10px;
  }

  .product-section .box_products .action-buttons .btn{
    width:100%
  }

    .product-section .box_products .img-icon{
    width:20px;
  }

  .product-section .all_brands li{
    list-style: none;
    font-weight:bold;
  }

  .product-section .all_brands li:hover{
      color:#c72429;
      cursor: pointer;
  }

   .product-section .btn-offcanva{
    display:none;
    width: fit-content;
   }

  @media(max-width:991px){
     .product-section .sidebar{
      display:none;
    }
    .product-section .btn-offcanva{
    display:block;
   }
  }
</style>
<main>
  <section class="product-section">
    <div class="container-fluid d-flex gap-5">

      <!-- SIDEBAR -->
      <div class="sidebar">
        <h5 class="fw-bold mb-3">Categories</h5>

        <!-- Accordion -->
        <div class="accordion" id="accordionExample">

          <!-- ALL BRANDS -->
        <div class="accordion-item">
          <h2 class="accordion-header">
            <span class="show-all-products btn btn-light w-100 text-start">All Brands</span>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              <ul class="all_brands">
                <?php foreach($all_brands as $brand): ?>
                  <li class="brand-filter" data-brand="<?php echo $brand; ?>"><?php echo $brand; ?></li>
                <?php endforeach; ?>
              </ul>
            </div>
          </div>
                </div>


          <!-- CATEGORIES -->
          <?php 
          $get_categories = $conn->prepare("SELECT * FROM categories");
          $get_categories->execute();
          $result_categories = $get_categories->get_result();
          if ($result_categories->num_rows > 0) {
            while ($row_categories = mysqli_fetch_assoc($result_categories)) {
              $category_name = htmlspecialchars($row_categories['category_name']);
              $category_id  = htmlspecialchars($row_categories['category_id']);
              $accordion_id = "cat_" . $category_id;
          ?>
          <div class="accordion-item">
            <h2 class="accordion-header" id="heading-<?php echo $accordion_id; ?>">
              <button class="accordion-button collapsed category-filter" type="button"
                      data-category="<?php echo $category_id; ?>"
                      data-bs-toggle="collapse"
                      data-bs-target="#<?php echo $accordion_id; ?>"
                      aria-expanded="false"
                      aria-controls="<?php echo $accordion_id; ?>">
                <?php echo $category_name; ?>
              </button>
            </h2>
            <div id="<?php echo $accordion_id; ?>" class="accordion-collapse collapse"
                 aria-labelledby="heading-<?php echo $accordion_id; ?>"
                 data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <ul class="all_brands">
                  <?php
                  $get_its_brand = $conn->prepare("SELECT DISTINCT brand_name FROM products WHERE category = ?");
                  $get_its_brand->bind_param("s", $category_id);
                  $get_its_brand->execute();
                  $result_brand = $get_its_brand->get_result();
                  if ($result_brand->num_rows > 0) {
                    while ($row_its_brand = mysqli_fetch_assoc($result_brand)) {
                      $brand_name = htmlspecialchars($row_its_brand['brand_name']);
                      ?>
                      <li class="brand-filter" data-brand="<?php echo $brand_name; ?>"><?php echo $brand_name; ?></li>
                      <?php
                    }
                  }
                  ?>
                </ul>
              </div>
            </div>
          </div>
          <?php
            }
          }
          ?>
        </div>
        <!-- End Accordion -->
      </div>

      <!-- MAIN CONTENT -->
     <div class="main-content">
    <a href="" class="btn btn-offcanva btn-primary mb-3" type="button" 
       data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" 
       aria-controls="offcanvasScrolling">Categories</a>

    <h5 class="fw-bold mb-3">All Products</h5>

    <div class="inner-content">
        <div class="row">

            <?php

            $best_seller_query = $conn->prepare("
                SELECT product_id, SUM(quantity) AS total_quantity
                FROM checkout
                GROUP BY product_id
                ORDER BY total_quantity DESC
                LIMIT 1
            ");
            $best_seller_query->execute();
            $result_best_seller = $best_seller_query->get_result();
            $best_seller_id = $result_best_seller->num_rows > 0 
                                ? $result_best_seller->fetch_assoc()['product_id'] 
                                : null;

           $search = isset($_GET['search']) ? urldecode(trim($_GET['search'])) : '';

            if (!empty($search)) {
              $like = "%" . strtolower($search) . "%";
              $active = 'Active';
          $get_products = $conn->prepare("
              SELECT * FROM products
              WHERE LOWER(product_name) LIKE ?
              OR LOWER(brand_name) LIKE ?
              OR LOWER(category) LIKE ? AND `status` = ?
          ");
          $get_products->bind_param("ssss", $like, $like, $like,$active);

            } else {
                $active = 'Active';
                $get_products = $conn->prepare("SELECT * FROM products WHERE  `status` = ?");
                $get_products->bind_param("s", $active);

            }

            $get_products->execute();
            $result_products = $get_products->get_result();

            // DISPLAY PRODUCTS
            if ($result_products->num_rows > 0) {
                while ($row_products = mysqli_fetch_assoc($result_products)) {

                    $product_id   = htmlspecialchars($row_products['product_id']);
                    $product_name = htmlspecialchars($row_products['product_name']);
                    $brand_name   = htmlspecialchars($row_products['brand_name']);
                    $category     = htmlspecialchars($row_products['category']);
                    $price        = htmlspecialchars($row_products['price']);

                    // Get product image
                    $get_product_images = $conn->prepare("
                        SELECT * FROM images 
                        WHERE product_id = ? 
                        LIMIT 1
                    ");
                    $get_product_images->bind_param("s", $product_id);
                    $get_product_images->execute();
                    $result_image = $get_product_images->get_result();
                    $image_name = "";

                    if ($result_image->num_rows > 0) {
                        $row_images = mysqli_fetch_assoc($result_image);
                        $image_name = htmlspecialchars($row_images['image_name'] ?? '');
                    }

                    $is_best_seller = ($product_id == $best_seller_id);
            ?>

            <div class="col-lg-3 col-md-6 col-sm-12 mb-3 product-card"
                data-brand="<?php echo $brand_name; ?>"
                data-category="<?php echo $category; ?>">

                <div class="box_products"
                     onclick="location.href='view_products.php?product_id=<?php echo $product_id; ?>'">

                    <div class="img-con">
                        <img src="../uploads/<?php echo $image_name; ?>" class="img-fluid" alt="">
                        <p><?php echo $brand_name; ?></p>
                    </div>

                    <div class="details-con">

                        <?php if ($is_best_seller): ?>
                        <div class="ribbon-wrapper ribbon-lg">
                            <div class="ribbon bg-danger">Best Seller</div>
                        </div>
                        <?php endif; ?>

                        <p><?php echo $product_name; ?></p>
                        <p class="text-danger fw-bold">&#8369; 
                            <?php echo number_format($price, 2); ?>
                        </p>

                        <div class="action-buttons d-flex flex-column">
                            <a href="add_to_cart.php?product_id=<?php echo $product_id; ?>" 
                               class="btn btn-outline-danger">
                                <img src="../image/my_cart-icon.png" class="img-icon"> Add&nbsp;Cart
                            </a>

                            <a href="buy_now.php?product_id=<?php echo $product_id; ?>" 
                               class="btn btn-outline-dark">
                                <img src="../image/checkout-icon.png" class="img-icon"> Buy&nbsp;Now
                            </a>
                        </div>

                    </div>
                </div>
            </div>

            <?php
                }
            } else {
                echo "<div class='text-center'><h3>No Products Found</h3></div>";
            }
            ?>

        </div>
    </div>
</div>

    </div>
  </section>
</main>

<!-- FILTERING SCRIPT -->
<script>
  document.addEventListener("DOMContentLoaded", function () {

  const products = document.querySelectorAll(".product-card");

  // CATEGORY FILTER
  document.querySelectorAll(".category-filter").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();

      const category = btn.getAttribute("data-category");

      products.forEach(p => {
        p.style.display = (p.getAttribute("data-category") === category) ? "" : "none";
      });
    });
  });

  // BRAND FILTER
  document.querySelectorAll(".brand-filter").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();

      const brand = btn.getAttribute("data-brand");

      products.forEach(p => {
        p.style.display = (p.getAttribute("data-brand") === brand) ? "" : "none";
      });
    });
  });

  // SHOW ALL → outside accordion header
  const allBtn = document.querySelector(".show-all-products"); // <- new class
  if (allBtn) {
    allBtn.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();

      products.forEach(p => p.style.display = "");
    });
  }

});

document.addEventListener("DOMContentLoaded", function() {

  const categoryButtons = document.querySelectorAll(".category-filter");
  const brandButtons = document.querySelectorAll(".brand-filter");
  const allBrandsButton = document.querySelector(".category-filter-all");
  const products = document.querySelectorAll(".product-card");


  categoryButtons.forEach(button => {
    button.addEventListener("click", function(e) {
      e.stopPropagation();

      const category = this.getAttribute("data-category");

      products.forEach(product => {
        if (product.getAttribute("data-category") === category) {
          product.style.display = "";   // show
        } else {
          product.style.display = "none"; // hide
        }
      });
    });
  });


  brandButtons.forEach(brand => {
    brand.addEventListener("click", function(e) {
      e.stopPropagation(); // stop accordion toggle

      const brandName = this.getAttribute("data-brand");

      products.forEach(product => {
        if (product.getAttribute("data-brand") === brandName) {
          product.style.display = "";   // show
        } else {
          product.style.display = "none"; // hide
        }
      });
    });
  });


  if (allBrandsButton) {
    allBrandsButton.addEventListener("click", function(e) {
      e.stopPropagation();
      products.forEach(product => {
        product.style.display = ""; 
      });
    });
  }

});
</script>



<?php include 'footer.php'; ?>
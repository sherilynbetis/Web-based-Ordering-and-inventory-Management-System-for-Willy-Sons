<?php 
    include 'index.php'; 

?>




<style>
.profile-section .header{
    padding:10px;
    background:#f7f7f7;
}
.profile-section .content .head{
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    background:red;
    padding:50px 30px 30px 20px;
    background:#f7f7f7;
    margin-bottom: 20px;
}
.profile-section .head img{
    width:100px;
    aspect-ratio: 1/1;
    margin-bottom:10px;
}
.profile-section .head p{
    font-weight: bold;
}

.profile-section li{
    list-style: none;
    margin-bottom: 10px;
}
</style>

<main>
    <section class="profile-section">
        <form action="function.php" method="POST">
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content ">
                <div class="modal-body p-0 ">
                    <div class="header text-end">
                        <button type="button" onclick="location.href='index.php'" class="btn-close mb-3" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="content">
                        <div class="head">
                            <img src="<?php echo $profile_path; ?>" alt="">
                            <p><?php echo $fullnameko; ?></p>
                            <!--<a href="profile_edit.php"><i class="bi bi-pencil-square text-dark"></i></a>-->
                        </div>
                        <ul>
                            <li>
                                <h6 class="fw-bold">Email</h6>
                                <p><?php echo $emailko; ?></p>
                            </li>
                            <li>
                                <h6 class="fw-bold">Phone Number</h6>
                                <p><?php echo $phone_numberko; ?></p>
                            </li>
                            <li>
                                <h6 class="fw-bold">Address</h6>
                                <p><?php echo $addressko ?? 'Not Updated';?></p>
                            </li>
                            <li>
                                <h6 class="fw-bold">Street</h6>
                                <p><?php echo $streetko ?? 'Not Updated'; ?></p>
                            </li>
                            <li>
                                <h6 class="fw-bold">Purok</h6>
                                <p><?php echo $purokko ?? 'Not Updated'; ?></p>
                            </li>
                        </ul>
                    </div>
                </div>
                </div>
            </div>
        </div>
        </form>
    </section>
</main>


<?php 
    include 'index.php'; 

?>




<main>
    <section class="profile-section">
        <form action="function.php" method="POST" enctype="multipart/form-data">
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog ">
                <div class="modal-content ">
                <div class="modal-body ">
                    <div class="header text-end">
                        <button type="button" onclick="location.href='index.php'" class="btn-close mb-3" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="content">
                        <div class="mb-3">
                            <label for="" class="form-label">Profile Picture</label>
                            <input type="file" class="form-control" name="profile" accept=".jpg,.png">
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Lastname</label>
                            <input type="text" class="form-control" name="lastname" value="<?php echo $lastnameko; ?>"  placeholder="Enter Lastname" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Firstname</label>
                            <input type="text" class="form-control" name="firstname" value="<?php echo $firstnameko; ?>" placeholder="Enter Firstname" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" placeholder="09" name="phone_number" placeholder="Phone Number" value="<?php echo $phone_numberko; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Email</label>
                            <input type="email" class="form-control" placeholder="Enter Email" name="email" value="<?php echo $emailko; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Address</label>
                            <input type="text" class="form-control" placeholder="Enter Address" name="address" value="<?php echo $addressko; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Street</label>
                            <input type="text" class="form-control" placeholder="Enter Street" name="street" value="<?php echo $streetko; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Purok</label>
                            <input type="text" class="form-control" placeholder="Enter Purok" name="purok" value="<?php echo $purokko; ?>" required>
                        </div>
                        <div class="mb-3 text-end">
                            <input type="submit" name="update_info" class="btn btn-primary" value="Update">
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        </form>
    </section>
</main>


<?php

include '../config.php';

$count_cart = $conn->prepare("SELECT COUNT(*) as `total_cart` FROM `cart` WHERE `user_id` = ? ");
$count_cart->bind_param("s",$user_idko);
$count_cart->execute();
$result_count = $count_cart->get_result();
if($result_count->num_rows>0){
    while($row_count = mysqli_fetch_assoc($result_count)){
        $total_cart = htmlspecialchars($row_count['total_cart'] ?? 0);
        echo "$total_cart";
    }
}
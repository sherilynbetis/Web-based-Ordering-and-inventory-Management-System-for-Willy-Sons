<?php

include 'index.php';

if(isset($_GET['cart_id'])){
    $cart_id = $_GET['cart_id'] ?? '';
}
?>
<main>
    <section class="remove-cart-section">
      <form action="function.php" method="POST">
          <!-- Modal -->
        <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header border-0">
                <input type="hidden" name="cart_id" value="<?php echo $cart_id; ?>">
            </div>
            <div class="modal-body text-center">
                Are Your sure to remove this Product?
            </div>
            <div class="modal-footer border-0">
                <button onclick="location.href='cart.php'" type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="submit" name="remove_product" class="btn btn-danger">Yes</button>
            </div>
            </div>
        </div>
        </div>
      </form>
    </section>
</main>
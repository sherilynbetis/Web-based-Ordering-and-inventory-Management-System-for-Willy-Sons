<?php 
    include 'index.php'; 
   if(isset($_GET['product_id'])){
    $product_id = $_GET['product_id'] ?? '';
   }

     $get= $conn->prepare("SELECT * FROM `products` WHERE `product_id` = ?");
    $get->bind_param("s",$product_id);
    $get->execute();
    $result_products = $get->get_result();
    if($result_products->num_rows>0){
        while($row_products = mysqli_fetch_assoc($result_products)){
            $product_name = htmlspecialchars($row_products['product_name']);
            $brand_name   = htmlspecialchars($row_products['brand_name']);
            $category     = htmlspecialchars($row_products['category']);
            $status       = htmlspecialchars($row_products['status']);
            $price        = htmlspecialchars($row_products['price']);
            $stocks       = htmlspecialchars($row_products['stocks']);
            $description       = htmlspecialchars($row_products['description']);
        }
    }
    

    $get_category = $conn->prepare("SELECT * FROM `categories` WHERE `category_id` = ?");
    $get_category->bind_param("s",$category);
    $get_category->execute();
    $result_cat = $get_category->get_result();
    if($result_cat->num_rows>0){
        while($row_cat = mysqli_fetch_assoc($result_cat)){
            $category_name = htmlspecialchars($row_cat['category_name'] ?? 'No Category');
        }
    }
?>


<!-- Bootstrap2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Splide CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/css/splide.min.css">
<!-- Bootstrap2 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Splide JS -->
<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide/dist/js/splide.min.js"></script>

<style>
    .view-product-section .featured-img{
        width:100%;
        aspect-ratio: 1/1;
    }
    .view-product-section .button-actions img{
        width:20px;
    }

    .view-product-section .button-actions {
        text-align: end;
    }
</style>
<main>
    <section class="view-product-section">
        <form action="function.php" method="POST">
            <div class="modal fade" id="system_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content ">
                <div class="modal-body">
                    <div class="header text-end">
                        <button type="button" onclick="location.href='index.php'" class="btn-close mb-3" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="content">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="splide mb-3">
                                    <div class="splide__track">
                                        <ul class="splide__list">
                                        <?php
                                        $count_images = 0;
                                        $images = $conn->prepare("SELECT * FROM `images` WHERE `product_id` = ?");
                                        $images->bind_param("s", $product_id);
                                        $images->execute();
                                        $result_images = $images->get_result();
                                        if ($result_images->num_rows > 0) {
                                            while ($row_img = mysqli_fetch_assoc($result_images)) {
                                                $image_name = htmlspecialchars($row_img['image_name']);
                                                echo '<li class="splide__slide"><img src="../uploads/' . $image_name . '" class="featured-img" alt=""></li>';
                                                $count_images++;
                                            }
                                        }
                                        ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="details">
                                    <h6><?php echo $brand_name; ?></h6>
                                    <h2><?php echo $product_name . ' ' . '(' . $category_name . ')' ;?></h2>
                                    <h6 class="fw-bold text-danger">&#8369; <?php echo $price; ?></h6>
                                    <p>Stocks: <?php echo $stocks; ?></p>
                                    <h6  class="m-0 fw-bold">Description</h6>
                                    <p>
                                        <?php echo nl2br(htmlspecialchars($description ?? '')); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="button-actions">
                            <a href="add_to_cart.php?product_id=<?php echo $product_id; ?>" class="btn btn-outline-danger"><img src="../image/my_cart-icon.png" class="img-icon" alt=""> add cart<a>
                            <a href="buy_now.php?product_id=<?php echo $product_id; ?>" class="btn btn-outline-dark"><img src="../image/checkout-icon.png" class="img-icon" alt=""> Buy Now</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        </form>
    </section>
</main>


<script>
     document.addEventListener("DOMContentLoaded", () => {
    var splide = new Splide('.splide', {
      type   : 'loop',
      padding: '2rem',
      arrows : <?= ($count_images > 1 ? 'true' : 'false') ?>,
      pagination : <?= ($count_images > 1 ? 'true' : 'false') ?>
    });
    splide.mount();
});
</script>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2025 at 05:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `willt_sons_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `user_id` varchar(255) NOT NULL,
  `lastname` text NOT NULL,
  `firstname` text NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `user_type` text NOT NULL,
  `token` text DEFAULT NULL,
  `profile` text DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `street` text DEFAULT NULL,
  `purok` text DEFAULT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`user_id`, `lastname`, `firstname`, `phone_number`, `email`, `password`, `user_type`, `token`, `profile`, `address`, `street`, `purok`, `status`) VALUES
('1086601629692701e2cd24a', 'BETIS', 'SHERILYN', '09383657572', 'SHERILYNBETS@GMAIL.COM', '$2y$10$DgWR219g.pmqIoPhFKQzEulpJzKY1oMBo9GVtug3C/XVnx1YNYW12', 'Customer', NULL, NULL, NULL, NULL, NULL, 'Active'),
('114485232468e8d28e19d54', 'admin', 'admin', '09095416801', 'admin@gmail.com', '$2y$10$Veufa8tS55ATiOxpL3UVZe0Wxxd5.9aIfs9QikJKkQ503oIN30MVm', 'Admin', '685cfbe67c039c0b13eda638613641f2107a54db406c2c12f685445f9935f6a1', NULL, NULL, NULL, NULL, 'Active'),
('124446598469293f505e162', 'Gerero', 'Ruth Jane', '09937166849', 'ruthjanegerero@gmail.com', '$2y$10$YdlyZWYAN.8yBh7xhaG.XeHUB/sURYeYBRBd2xMgWj4WMeIZuNAEu', 'Customer', '4af1d49cd64e9287c761a764c9352ce89cba4a875182ac82bfe3909789cf9be0', NULL, NULL, NULL, NULL, 'Active'),
('1744319763692704ec87449', 'Betis', 'Sherilyn', '09923277543', 'sherilynbetis@gmail.com', '$2y$10$kARVSVkpj403IjrrL7Yhe.nARNgT72aERLHWUh01C05A9PJZ3l186', 'Customer', '45669fdca164a2ba25d2b69b00f6168da0803ef92321a6d4b89ccad19fdc03c9', NULL, '2as', 'dasd', '2', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `best_seller`
--

CREATE TABLE `best_seller` (
  `best_seller_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `total` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `product_id`, `date`, `time`, `quantity`, `total`) VALUES
('1323167972', '124446598469293f505e162', '185988402769293e8e8c0f8', '2025-11-28', '03:32:57 pm', '2', '200.00'),
('1396809102', '124446598469293f505e162', '12334371856927b38b33ac7', '2025-11-28', '02:25:07 pm', '', '4,555.00'),
('1835326653', '124446598469293f505e162', '17620816786927b46348c34', '2025-11-28', '02:23:00 pm', '', '4,555.00');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` varchar(255) NOT NULL,
  `category_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
('1480864046', 'ELECTRONICS DEVICE'),
('930002825', 'HOME APPLIANCES'),
('982246103', 'HOME FURNITURE');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `checkout_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` text NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `expiration_date` varchar(255) NOT NULL,
  `expiration_time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`checkout_id`, `user_id`, `product_id`, `date`, `time`, `quantity`, `total`, `status`, `expiration_date`, `expiration_time`) VALUES
('460393621', '124446598469293f505e162', '316926036929b905a7425', '2025-11-29', '12:26:50 pm', '1', '5,999.00', 'Claimed', '11/30/2025', '12:26:56 pm');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_id` varchar(255) NOT NULL,
  `image_name` text NOT NULL,
  `product_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`image_id`, `image_name`, `product_id`) VALUES
('1147063261', 'c4e91fa1-4648-499c-ae6c-43b914559cff.jpg', '3688790496929c5a7ae866'),
('1318395389', '591572368_25525989237037515_3075270369207200687_n (1).jpg', '15069113626929bba87017f'),
('1421689231', 'Screenshot 2025-11-05 222938.png', '182883087469269a4adf431'),
('1703274375', 'e8eeeef1-12dc-49eb-92cb-24c49233b5f2.jpg', '8460064956929c27723238'),
('40851441', '993aed24-eac2-4fcf-b3ab-aaf15e0ad280.jpg', '20433711786929c15a39e25'),
('639820214', '589654414_1847002299509311_8219995090597974199_n.jpg', '316926036929b905a7425');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `log_id` varchar(255) NOT NULL,
  `action` text NOT NULL,
  `date` date NOT NULL,
  `type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`log_id`, `action`, `date`, `type`) VALUES
('1054559201', 'Subtracted 10 from note 10 (New total: 2)', '2025-11-28', 'Stock Out'),
('1061485044', 'Order Claimed', '2025-11-27', 'Order'),
('1113869020', 'Order Claimed', '2025-11-27', 'Order'),
('1175869723', 'Added 10 to note 10 (New total: 10)', '2025-11-27', 'Stock In'),
('1259156565', 'Added 23 to asd (New total: 23)', '2025-11-26', 'Stock In'),
('1413789091', 'Order Claimed', '2025-11-27', 'Order'),
('1664306132', 'Added 23 to samsumg s12 (New total: 23)', '2025-11-27', 'Stock In'),
('1824727865', 'Added 10 to note 10 (New total: 10)', '2025-11-27', 'Stock In'),
('1904428744', 'Order Claimed', '2025-11-26', 'Order'),
('2045788912', 'Added 5 to Cellphone (New total: 5)', '2025-11-28', 'Stock In'),
('2100764995', 'Subtracted 10 from note 10 (New total: 0)', '2025-11-28', 'Stock Out'),
('418769302', 'Order Claimed', '2025-11-29', 'Order'),
('440138724', 'Added 5 to note 10 (New total: 7)', '2025-11-28', 'Stock In'),
('442717396', 'Added 4 to note 10 (New total: 14)', '2025-11-27', 'Stock In'),
('547950850', 'Added 6 to Xiomi (New total: 6)', '2025-11-28', 'Stock In'),
('897226975', 'Added 4 to Cellphone (New total: 4)', '2025-11-27', 'Stock In');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `receiver` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(255) NOT NULL,
  `product_name` text NOT NULL,
  `brand_name` text NOT NULL,
  `category` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `price` text NOT NULL,
  `stocks` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `brand_name`, `category`, `status`, `price`, `stocks`, `description`) VALUES
('15069113626929bba87017f', 'Air Conditioner', 'TCL', '930002825', 'Active', '34495', '', 'TAC-CSA/KEI\r\n1.0 HP INVERTER Split Type AC\r\n\r\nSplit wall-Mounted I 5D DC Inverter\r\nVariables Speed (Inverter) Cooling Only\r\nTitan Gold Technology I 5-in-1 Health filters\r\n\r\nSRP: ₱34,495'),
('20433711786929c15a39e25', 'SOFA', 'JANDY SOFA STANDARD', '982246103', 'Active', '23200', '', 'Modern Furniture\r\nNew collection\r\n\r\nModel:\r\n   JADY SOFA STANDARD\r\nPHP: ₱ 23,200'),
('316926036929b905a7425', 'Xiomi', 'REDMI', '1480864046', 'Active', '5999', '5', 'Model : 14C\r\n\r\nSHORT SPECS\r\nOperating system: Android 14, HyperOS\r\nProcessor: Mediatek Helli G81 Ultra (12nm) octa-core\r\nGPU: Mall-G52 MC2\r\n\r\nCamera:\r\n    Main Cam : 50MP(wide), PDAF or PDAF QVGA\r\n     Selfie Cam: 13MP (wide)\r\n\r\nBattery: 5160 mah, 18W wired, PD\r\nDisplay: 720x1604 pixels, COrning Gorilla Glass 5\r\n\r\nCapacity: 8GB = 256GB\r\n\r\nSRP/PHP: 5,999\r\n\r\nAvail additional discount on cash purchase.'),
('3688790496929c5a7ae866', 'Refregirator', 'TCL', '930002825', 'Active', '42995', '', 'TRF-INV430CDSS\r\n15.0 CU. FT, Inverter\r\nMulti Door Fridge\r\n\r\nAutomatic Anion\r\nReleasing Technology\r\nTemperature Control\r\nTwin Eco Inventer\r\n\r\nSRP: ₱42,995\r\nCash:₱27,995\r\nAvail Additional cash discount on Purchase'),
('8460064956929c27723238', 'SOFA', 'JANELLA SOFA', '982246103', 'Active', '32820', '', 'Modern Furniture\r\nNew Collection\r\n\r\nModel:\r\nJanella Sofa\r\nPHP: ₱32,890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `best_seller`
--
ALTER TABLE `best_seller`
  ADD PRIMARY KEY (`best_seller_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`checkout_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
include 'config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'email-sender/src/Exception.php';
require 'email-sender/src/PHPMailer.php';
require 'email-sender/src/SMTP.php';

if(isset($_POST['register_account'])){
   $firstname = $_POST['firstname'];
   $lastname = $_POST['lastname'];
   $email = $_POST['email'];
   $phone_number = $_POST['phone_number'];
   $password = $_POST['password'];
   $repeat_password = $_POST['repeat_password'];


   $_SESSION['firstname'] = $firstname;
   $_SESSION['lastname'] = $lastname;
   $_SESSION['email'] = $email;
   $_SESSION['phone_number'] = $phone_number;
   $_SESSION['password'] = $password;
   $_SESSION['repeat_password'] = $repeat_password;


    $get_email = $conn->prepare("SELECT * FROM `accounts` WHERE `email` = ?");
    $get_email->bind_param("s",$email);
    $get_email->execute();
    $result_email = $get_email->get_result();
    if($result_email->num_rows>0){
        $_SESSION['error'] = "Email Already Taken";
        header("location:register.php");
        exit;
    }

    $get_phone_number = $conn->prepare("SELECT * FROM `accounts` WHERE `phone_number` =?");
    $get_phone_number->bind_param("s",$phone_number);
    $get_phone_number->execute();
    $result_phone = $get_phone_number->get_result();
    if($result_phone->num_rows>0){
        $_SESSION['error'] = "Phone Number Already Taken";
        header("location:register.php");
        exit;
    }

    if($password !== $repeat_password){
        $_SESSION['error'] = "Password and Confirm Password not Match";
        header("location:register.php");
        exit;
    }else{
        $user_id = rand() . uniqid();
        $user_type = 'Customer';
        $Active = 'Active';
        $hash_pass =  password_hash($password, PASSWORD_DEFAULT);
        $insert = $conn->prepare("INSERT INTO `accounts` (`user_id`,`lastname`,`firstname`,`phone_number`,`email`,`password`,`user_type`,`status`) VALUES (?,?,?,?,?,?,?,?)");
        $insert->bind_param("ssssssss",$user_id,$lastname,$firstname,$phone_number,$email,$hash_pass,$user_type,$Active);
        $insert->execute();
        unset($_SESSION['firstname']);
        unset($_SESSION['lastname']);
        unset($_SESSION['email']);
        unset($_SESSION['phone_number']);
        unset($_SESSION['password']);
        unset($_SESSION['repeat_password']);
        $_SESSION['success'] = "Successfully Registered";
        header("location:register.php");
        exit;

    }

  
}

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $active = 'Active';
    $get_admin = $conn->prepare("SELECT * FROM `accounts` WHERE `email` = ? AND `status` = ?");
    $get_admin->bind_param("ss", $email,$active);

    if ($get_admin->execute()) {
        $result = $get_admin->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $hashed_password = $row['password']; 

            if (password_verify($password, $hashed_password)) {
                // login success
                $user_id = $row['user_id'];
                $user_type = $row['user_type'];

                $_SESSION['active_login'] = $user_id;

                // ✅ Generate secure token
                $token = bin2hex(random_bytes(32)); // 64-character secure token

                // ✅ Save token in DB
                $update_token = $conn->prepare("UPDATE accounts SET token = ? WHERE user_id = ?");
                $update_token->bind_param("ss", $token, $user_id);
                $update_token->execute();

                // ✅ Set cookie for 7 days
                setcookie("remember_token", $token, time() + (7 * 24 * 60 * 60), "/", "", false, true); // httponly

                // ✅ Redirect
                if ($user_type === "Admin") {
                    header('Location: admin');
                } elseif ($user_type === "Customer") {
                    header('Location: customer');
                } else {
                    header('Location: index.php');
                }
                exit;
            } else {
                $_SESSION['error'] = "Invalid Username or Password";
                header('Location: login.php');
                exit;
            }
        } else {
            $_SESSION['error'] = "User not Found";
            header('Location: login.php');
            exit;
        }
    } else {
        $_SESSION['error'] = "Technical Error";
        header('Location: login.php');
        exit;
    }
}

if(isset($_POST['send_verification'])){
    $email = $_POST['email'] ?? '';
    $new_password = $_POST['new_password'] ?? '';


    $get_email = $conn->prepare("SELECT * FROM `accounts` WHERE `email` = ?");
    $get_email->bind_param("s",$email);
    $get_email->execute();
    $result_email = $get_email->get_result();
    if($result_email->num_rows>0){
        while($row_user = mysqli_fetch_assoc($result_email)){
            $fullname = htmlspecialchars($row_user['lastname']) . ' ' . htmlspecialchars($row_user['firstname']);
            
             $verification_code = rand(100000, 999999);
        $subject = "WILL & SONS FORGOT PASSWORD VERIFICATION ";
        $message = "
            <p>Dear $fullname,</p>

            <p>Thank you for using the <strong>WILL & SONS</strong>.  
            To complete your verification, please use the code below:</p>

            <h2 style='color:#2c7be5;letter-spacing:3px;'>$verification_code</h2>

            <p>This code will expire in <strong>5 minutes</strong>.  
            If you did not request this verification, please ignore this email.</p>

            <p>Best regards,</p>
            <p><strong>WILL & SONS</strong></p>
            ";

        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->CharSet = 'UTF-8';  
            $mail->Encoding = 'base64';
            $mail->SMTPAuth = true;
            $mail->Username = 'willyandsonsbulan@gmail.com';
            $mail->Password = 'efzy frsw wfup szbz'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 
            $mail->Port = 465;


            $mail->setFrom('willyandsonsbulan@gmail.com', 'WILL & SONS Verification');
            $mail->addAddress($email);

        
            $mail->isHTML(true);
            $mail->Subject = $subject;
        $mail->Body   = $message;

            // Send email
            $mail->send();

            $_SESSION['verification'] = $verification_code;
            $_SESSION['email'] = $email;
            $_SESSION['new_password'] = $new_password;
            $_SESSION['success'] = "Please Check Your Email For Verification Number has been Sent";
            header("location:verifi_password.php");
            exit;

            
        } catch (Exception $e) {
            $_SESSION['error'] = "Slow / No Internet, please Check your Internet!";
            header("Location:forgot_password.php");
            exit;
        }

        }
    }else{
        $_SESSION['error'] = "USER NOT FOUND";
        header("location:forgot_password.php");
        exit;
    }
}


if(isset($_POST['verifi_password'])){
    $input_code = $_POST['input_code'] ?? '';
    $verification_code = $_SESSION['verification'];
    $email = $_SESSION['email'];
    $new_password = $_SESSION['new_password'];


    if((int)$input_code === (int)$verification_code){
        $hash_pass =  password_hash($new_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE accounts SET `password` = ? WHERE `email` = ?");
        $update->bind_param("ss",$hash_pass,$email);
        $update->execute();
        unset($_SESSION['verification']);
        unset($_SESSION['email']);
        unset($_SESSION['new_password']);
        $_SESSION['success'] = "Successfully Changed Password";
        header("location:login.php");
        exit;
    }else{
        $_SESSION['error'] = "Verification not Match";
        header("location:verifi_password.php");
        exit;
    }
}
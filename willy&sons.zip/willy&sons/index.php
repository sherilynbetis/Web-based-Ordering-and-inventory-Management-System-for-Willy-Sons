<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="shortcut icon" href="image/logo.jpg" type="image/x-icon">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="landing_page">
  <?php
      include 'config.php';
      include 'cookies.php';
  ?>
 <!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-white shadow-sm  fixed-top">
  <div class="container">
    <!-- Logo + Brand -->
    <a class="navbar-brand d-flex align-items-center p-0 " href="#">
      <img src="image/logo.png" alt="Willy & Sons Logo" 
           style="width: 100px; margin-right: 12px;">
      <span class="fw-bold text-danger fs-3" >Willy & Sons</span>
    </a>

    <!-- Toggler -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <img style="width: 30px;aspect-ratio: 1/1;" src="image/icon_hamburger.png" alt="image/icon_hamburger.png">
    </button>

    <!-- Nav Links -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item"><a class="nav-link fw-bold text-dark" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link fw-bold text-dark" href="#about">About</a></li>
        <li class="nav-item"><a class="nav-link fw-bold text-dark" href="#offer">What We Offer</a></li>
        <li class="nav-item"><a class="nav-link fw-bold text-dark"  href="#values">Our Values</a></li>
    
      </ul>
      <div>
        <a href="login.php" class="btn btn-outline-danger me-2">Sign In</a>
        <a href="register.php" class="btn btn-danger">Sign Up</a>
      </div>
    </div>
  </div>
</nav>


  <!-- Hero Section -->
  <section id="home" class="hero-section">
    <div class="container pt-5">
      <div class="row align-items-center">
        <!-- Left -->
        <div class="col-md-6">
          <span class="badge badge-hot mb-3">🔥 Hot Deals Available</span>
      <h1 class="hero-title">
       <span>Willy & Sons</span> – Your Trusted Partner in Home Appliances
      </h1>

          <p class="text-muted">
            Discover amazing deals on top-quality electronic appliances. Free shipping, 24/7 support, and guaranteed lowest prices on ovens, refrigerators, washing machines & more!
          </p>
          
          <div class="d-flex gap-3 my-3">
            <div class="feature-box">🚚 Free Delivery</div>
            <div class="feature-box">🛡️1-month Warranty</div>
            <div class="feature-box">📞 24/7 Support</div>
          </div>
          
          <div class="d-flex gap-4 mt-5">
            <div class="stats-box">
              <h3 class="text-danger">5000+</h3>
              <p class="mb-0">Happy Customers</p>
            </div>
            <div class="stats-box">
              <h3 class="text-danger">100+</h3>
              <p class="mb-0">Top Brands</p>
            </div>
            <div class="stats-box">
              <h3 class="text-danger">15+</h3>
              <p class="mb-0">Years Trusted</p>
            </div>
          </div>
        </div>

        <!-- Right -->
        <div class="col-md-6 position-relative">
          <img src="image/about-section.jpg" class="img-fluid rounded shadow" style="height: 400px;">
          <div class="discount-badge">50% OFF <br>Limited Time</div>
        </div>
      </div>
    </div>
  </section>

  <!-- About Section -->
  <section id="about" class="about-section">
    <div class="container">
      <div class="text-center mb-5">
        <h2 class="fw-bold">About Willy & Sons Electronics</h2>
        <p class="text-muted">
          For over 15 years, Willy & Sons has been the trusted destination for premium electronic appliances, 
          serving thousands of satisfied customers with quality products and exceptional service.
        </p>
      </div>
      <div class="row align-items-center">
        <div class="col-md-6 mb-4 mb-md-0">
          <img src="image/about-section.jpg" alt="Store Image">
        </div>
        <div class="col-md-6">
          <h4 class="fw-bold">Our Legacy</h4>
          <p>
            Founded in 2008, Willy & Sons began as a small family-owned electronics store with a vision 
            to provide high-quality home appliances at competitive prices. Today, we've grown into one 
            of the region's most trusted appliance retailers.
          </p>
          <p>
            We partner with leading brands like Samsung, LG, Whirlpool, Bosch, and GE to bring you the 
            latest in home appliance technology. Our commitment to quality and customer satisfaction has 
            made us the preferred choice for modern families.
          </p>

          <div class="d-flex gap-5 mt-4 about-stats">
            <div>
              <h4>15+</h4>
              <p class="mb-0">Years Serving</p>
            </div>
            <div>
              <h4>25K+</h4>
              <p class="mb-0">Happy Customers</p>
            </div>
            <div>
              <h4>50+</h4>
              <p class="mb-0">Brand Partners</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- What We Offer Section -->
  <section id="offer" class="offer-section">
    <div class="container">
      <div class="text-center mb-5">
        <h3>What We Offer</h3>
        <p class="text-muted">Explore our wide range of products and services designed to meet all your home appliance needs.</p>
      </div>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-kitchen-set"></i>
            <h5 class="fw-bold">Kitchen Appliances</h5>
            <p class="text-muted">Complete range of kitchen essentials including refrigerators, ovens, microwaves, dishwashers, and cooking ranges from top brands.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-soap"></i>
            <h5 class="fw-bold">Laundry Solutions</h5>
            <p class="text-muted">Advanced washing machines, dryers, and laundry care appliances designed for efficiency and fabric protection.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-snowflake"></i>
            <h5 class="fw-bold">Cooling & Heating</h5>
            <p class="text-muted">Air conditioners, heaters, fans, and climate control systems to keep your home comfortable year-round.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-tv"></i>
            <h5 class="fw-bold">Entertainment Systems</h5>
            <p class="text-muted">Smart TVs, sound systems, and home theater solutions for the ultimate entertainment experience.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-blender"></i>
            <h5 class="fw-bold">Small Appliances</h5>
            <p class="text-muted">Essential small appliances including blenders, coffee makers, toasters, and vacuum cleaners for daily convenience.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card service-card p-4 h-100 text-center">
            <i class="fa-solid fa-headset"></i>
            <h5 class="fw-bold">Expert Support</h5>
            <p class="text-muted">Professional installation, maintenance services, and 24/7 customer support for all your appliance needs.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Our Values Section -->
  <section id="values" class="values-section">
    <div class="container">
      <div class="text-center mb-5">
        <h2 class="fw-bold">Our Values</h2>
        <p class="text-muted">These core principles guide everything we do at Willy & Sons</p>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="value-box">
            <i class="fa-solid fa-check"></i>
            <h5 class="fw-bold">Quality Assurance</h5>
            <p>We only sell authentic, high-quality electronics from trusted brands with comprehensive warranties and after-sales support.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="value-box">
            <i class="fa-solid fa-headset"></i>
            <h5 class="fw-bold">Customer First</h5>
            <p>Our knowledgeable staff provides personalized service, helping you find the perfect electronics for your needs and budget.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="value-box">
            <i class="fa-solid fa-tags"></i>
            <h5 class="fw-bold">Best Prices</h5>
            <p>We offer competitive pricing and regular promotions to ensure you get the best value for your money.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <!-- Company Info -->
        <div class="col-md-4">
          <h5>Willy & Sons Electronics</h5>
          <p>Your trusted partner for premium electronic appliances. From kitchen essentials to entertainment systems, we provide quality products with exceptional service for over 15 years.</p>
          <p><i class="fa-solid fa-location-dot me-2"></i>123 Electronics Avenue, Tech City, TC 12345</p>
          <p><i class="fa-solid fa-phone me-2"></i>(555) 123-4567</p>
          <p><i class="fa-solid fa-envelope me-2"></i>info@willyandsons.com</p>
          <div class="social-icons mt-3">
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-linkedin"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
        <!-- Links -->
        <div class="col-md-2">
          <h5>Company</h5>
          <a href="#">About Us</a><br>
          <a href="#">Store Locations</a><br>
          <a href="#">Careers</a>
        </div>
        <div class="col-md-3">
          <h5>Products</h5>
          <a href="#">Kitchen Appliances</a><br>
          <a href="#">Laundry Equipment</a><br>
          <a href="#">Climate Control</a><br>
          <a href="#">Entertainment Systems</a>
        </div>
        <div class="col-md-3">
          <h5>Support</h5>
          <a href="#">Customer Service</a><br>
          <a href="#">Installation Guide</a><br>
          <a href="#">Warranty Info</a><br>
          <a href="#">Repair Services</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

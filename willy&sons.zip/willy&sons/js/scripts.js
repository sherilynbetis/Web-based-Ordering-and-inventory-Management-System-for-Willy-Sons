document.addEventListener("DOMContentLoaded", ()=> {
      // Enable tooltips
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]')
  tooltipTriggerList.forEach(el => new bootstrap.Tooltip(el))
});


/* modal show*/
document.addEventListener("DOMContentLoaded", ()=> {
    let myModal = new bootstrap.Modal(document.getElementById('system_modal'));
    myModal.show();
});


document.addEventListener("DOMContentLoaded", ()=> {
      // Filter function
  const filterBtns = document.querySelectorAll(".filter-btn");
  const rows = document.querySelectorAll("#productTable tr");
  const searchInput = document.getElementById("searchInput");

  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => b.classList.remove("active", "btn-warning"));
      btn.classList.add("active", "btn-warning");
      const category = btn.getAttribute("data-category");

      rows.forEach(row => {
        if (category === "all" || row.getAttribute("data-category") === category) {
          row.style.display = "";
        } else {
          row.style.display = "none";
        }
      });
    });
  });

    // Search filter
  searchInput.addEventListener("keyup", () => {
    const term = searchInput.value.toLowerCase();
    rows.forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(term) ? "" : "none";
    });
  });
});
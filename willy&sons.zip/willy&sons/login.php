<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="shortcut icon" href="image/logo.jpg" type="image/x-icon">
  <script src="js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
</head>
<body class="login_body">

<?php 
  include 'config.php';
  include 'cookies.php';
?>

  <!-- Login Section -->
  <section class="login-section">
    <div class="container">
      <div class="login-card">

        <div class="text-center ">
          <img src="image/logo.png" alt="Logo" style="width:200px" class="img-fluid">
          <h3 class="mt-3">Welcome Back! </h3>
        </div>

        <form action="function.php" method="POST">
          <!-- Email -->
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="text" class="form-control" name="email" placeholder="Enter your email address" required>
          </div>
          <!-- Password -->
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" class="form-control" name="password" password="password" placeholder="Enter your password" required>
          </div>
          <!-- Remember me + Forgot -->
          <div class="d-flex justify-content-end align-items-end mb-3">
            <a href="forgot_password.php" class="forgot-link">Forgot password?</a>
          </div>
          <!-- Sign In -->
          <div class="d-flex mb-3 gap-2">
            <button type="submit" name="login" class="btn btn-login w-100"> Sign In</button>
            <button type="button" onclick="location.href='index.php'" class="btn btn-secondary w-100 p-0">Cancel</button>
          </div>
          <!-- Sign Up -->
          <p class="text-center mt-4">Don't have an account? <a href="register.php" class="text-danger fw-bold btn">Sign up for free 📝</a></p>
        </form>

      </div>
    </div>
  </section>

    <!-- Bootstrap JS -->
  <?php include 'alerts.php'; ?>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

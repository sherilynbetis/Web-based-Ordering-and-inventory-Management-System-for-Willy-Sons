<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons Register Account</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="shortcut icon" href="image/logo.jpg" type="image/x-icon">
  <script src="js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
</head>
<body class="register_body">

<?php
  include 'config.php';
  include 'cookies.php';
?>


  <!-- Register Section -->
  <section class="register-section" >
    <div class="container d-flex justify-content-center align-items-center">
      <div class="card shadow p-4 " >
      <div class="text-center mb-4">
        <img src="image/logo.png" class="featured-icon-logo img-fluid" alt="Logo" >
        <h3 class="mt-3 fw-bold">Join Willy & Sons! </h3>
        <p class="text-muted">Create your account for premium electronics</p>
      </div>

      <form action="function.php" method="POST">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">First Name</label>
            <input type="text" class="form-control" placeholder="John" name="firstname" value="<?php echo $_SESSION['firstname'] ?? '' ?>" required>
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">Last Name</label>
            <input type="text" class="form-control" placeholder="Doe" name="lastname" value="<?php echo $_SESSION['lastname'] ?? '' ?>" required>
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label">Email Address</label>
          <input type="email" class="form-control" placeholder="john.doe@example.com" name="email" value="<?php echo $_SESSION['email'] ?? '' ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Phone Number</label>
          <input type="text" class="form-control" placeholder="09" name="phone_number" placeholder="Phone Number" value="<?php echo $_SESSION['phone_number'] ?? '' ?>" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="password" minlength="10" value="<?php echo $_SESSION['password'] ?? '' ?>" placeholder="Create a strong password" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Confirm Password</label>
          <input type="password" class="form-control"  name="repeat_password" value="<?php echo $_SESSION['repeat_password'] ?? '' ?>" placeholder="Confirm your password" required>
        </div>

        <div class="button-actions">
          <button type="submit" name="register_account" class="btn btn-register w-100 mb-3"> Create Account</button>
          <button type="button" onclick="location.href='index.php'" class="btn btn-cancel w-100 h-50">Cancel</button>
        </div>

        <p class="text-center">Already have an account? <a href="login.php" class="text-danger fw-bold btn">Sign in here 👋</a></p>

      </form>

    </div>
    </div>
  </section>

     
  <?php include 'alerts.php'; ?>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

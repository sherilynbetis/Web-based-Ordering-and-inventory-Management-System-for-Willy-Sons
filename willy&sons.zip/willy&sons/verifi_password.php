<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Willy & Sons</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="shortcut icon" href="image/logo.jpg" type="image/x-icon">
  <script src="js/sweet_alert.js"></script>
  <script src="https://unpkg.com/@lottiefiles/dotlottie-wc@0.8.1/dist/dotlottie-wc.js" type="module"></script>
</head>
<body class="forgotpassword_body">

<?php 
  include 'config.php';
  include 'cookies.php';
?>


<style>
.forgotpassword_body{
      background:url("image/bg-willy&sons.jpg");
    width: 100%;
    background-size:cover;
    background-position: center;
}
.forgotpassword_body .forgot-password-section{
    padding:50px 0;
}
.forgotpassword_body .forgot-password-section form{
    width:500px;
    background:white;
    padding:30px;
    border-radius: 20px;
}

@media(max-width:761px){
    .forgotpassword_body .forgot-password-section form{
        width:100%;
    }
}
</style>

<main>
    <section class="forgot-password-section">
        <div class="container d-flex justify-content-center align-items-center">
            <form action="function.php" method="POST">
                <div class="mb-3 text-center">
                    <img src="image/logo.png" alt="Logo" style="width:200px" class="img-fluid">
                    <h3 class="fw-bold"> CONFIRM VERIFICATION</h3>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Enter Verification</label>
                    <input type="text" class="form-control" placeholder="Enter Your verification Code" name="input_code" required>
                </div>
                <div class="mb-3 d-flex gap-1">
                    <button type="submit" name="verifi_password" class="btn btn-send btn-danger w-100">Confirm</button>
                    <button type="button" onclick="location.href='login.php'" class="btn btn-secondary w-100">Cancel</button>
                </div>
            </form>
        </div>
    </section>
</main>






    
    <!-- Bootstrap JS -->
  <?php include 'alerts.php'; ?>
  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
